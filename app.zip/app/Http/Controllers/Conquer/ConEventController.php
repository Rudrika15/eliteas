<?php

namespace App\Http\Controllers\Conquer;

use App\Http\Controllers\Controller;
use App\Models\BusinessCategory;
use App\Models\ConquerEvent;
use App\Models\ConquerEventRegister;
use App\Models\User;
use App\Models\VisitorsDetails;
use App\Utils\ErrorLogger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ConEventController extends Controller
{
    public function main()
    {
        $event = ConquerEvent::where('status', 'Active')->first();
        return view('conquer.mainPage.main', compact('event'));
    }

    public function thankYou()
    {
        $event = ConquerEvent::where('status', 'Active')->first();
        return view('conquer.mainPage.thankYou', compact('event'));
    }

    public function visitor()
    {
        $event = ConquerEvent::where('status', 'Active')->first();
        $businessCategory = BusinessCategory::where('status', 'Active')->get();
        return view('conquer.mainPage.visitor', compact('businessCategory', 'event'));
    }

    public function conEventLogin(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
            'userId' => 'required|integer',
            'eventId' => 'required|integer',
        ]);

        // Fetch user from the database
        $user = User::where('email', $request->email)->first();

        // Check if user exists and password matches
        if ($user && Hash::check($request->password, $user->password)) {
            // Authentication successful, pass userId and eventId to the thank you page
            return redirect()->route('main.event.thankYou', [
                'userId' => $request->userId,
                'eventId' => $request->eventId
            ]);
        } else {
            // Authentication failed, redirect back with an error message
            return redirect()->back()->withErrors([
                'email' => 'The provided credentials do not match our records.',
            ])->withInput();
        }
    }


    public function conquerVisitorStore(Request $request)
    {
        try {
            // Create a new VisitorsDetails object
            $visitor = new ConquerEventRegister();
            $visitor->eventId = $request->eventId;
            // $visitor->userId = $request->userId;
            $visitor->firstName = $request->firstName;
            $visitor->lastName = $request->lastName;
            $visitor->contactNo = $request->contactNo;

            // Determine business category and assign it to the visitor
            if ($request->businessCategory == 'other') {
                // If 'other', assign the otherCategory value and check if already exists
                $business = BusinessCategory::where('categoryName', $request->otherCategory)->first();
                if (!$business) {
                    $business = new BusinessCategory();
                    $business->categoryName = $request->otherCategory;
                    $business->save();
                }
                $visitor->businessCategory = $business->id;
            } else {
                $visitor->businessCategory = $request->businessCategory;
            }

            $visitor->status = 'Active';

            // Save the visitor information
            $visitor->save();

            return redirect()->back()->with('success', 'Your Information Submitted Successfully!');
        } catch (\Throwable $th) {
            // Log the error
            // throw $th;
            ErrorLogger::logError($th, $request->fullUrl());
            // Return a generic error view or message
            return redirect()->back()->with('error', 'Failed to submit your information');
        }
    }

    public function eventLogin()
    {
        $event = ConquerEvent::where('status', 'Active')->first();
        return view('conquer.mainPage.eventLogin', compact('event'));
    }

    public function conquerUserStore(Request $request)
    {
        try {
            // Create a new VisitorsDetails object
            $visitor = new ConquerEventRegister();
            $visitor->eventId = $request->eventId;
            $visitor->userId = $request->userId;
            $visitor->status = 'Active';

            // Save the visitor information
            $visitor->save();

            return redirect()->back()->with('success', 'Your Information Submitted Successfully!');
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError($th, $request->fullUrl());
            // Return a generic error view or message
            return redirect()->back()->with('error', 'Failed to submit your information');
        }
    }
}
