@extends('layouts.master')

@section('header', 'Circle 1:1 Meeting')
@section('content')

{{-- Message --}}
@if (Session::has('success'))
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        {{-- <i class="fa fa-times"></i> --}}
    </button>
    <strong>Success !</strong> {{ session('success') }}
</div>
@endif

@if (Session::has('error'))
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        {{-- <i class="fa fa-times"></i> --}}
    </button>
    <strong>Error !</strong> {{ session('error') }}
</div>
@endif


<div class="card">
    <div class="card-body d-flex justify-content-between align-items-center">
        <h5 class="card-title">Create 1:1 Meeting</h5>
        <a href="{{ route('circlecall.index') }}" class="btn btn-secondary btn-sm">BACK</a>
    </div>

    <!-- Floating Labels Form -->
    <form class="m-3 needs-validation" id="circlecallForm" enctype="multipart/form-data" method="post"
        action="{{ route('circlecall.store') }}" novalidate>
        @csrf
        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-floating">
                    <select class="form-control" data-error='Circle Meeting Field is required' required name="circlememberId"
                        id="circlememberId">
                        <option value="" selected disabled> Select Circle Member </option>
                        @foreach ($circlemember as $circlememberData)
                        <option value="{{ $circlememberData->id }}">{{ $circlememberData->countryName }}</option>
                        @endforeach
                    </select>
                    @error('countryId')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-floating">
                    <select class="form-control" data-error='State Name Field is required' required name="stateId"
                        id="countryId">
                        <option value="" selected disabled> Select State </option>
                        @foreach ($state as $stateData)
                        <option value="{{ $stateData->id }}">{{ $stateData->stateName }}</option>
                        @endforeach
                    </select>
                    @error('stateId')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-floating mt-3">
                    <input type="text" class="form-control @error('cityName') is-invalid @enderror" id="stateName"
                        name="cityName" placeholder="City Name" required>
                    <label for="cityName">City Name</label>
                    @error('cityName')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>

        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="reset" class="btn btn-secondary">Reset</button>
        </div>
    </form><!-- End floating Labels Form -->
</div>

@endsection