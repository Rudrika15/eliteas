@extends('layouts.master')

@section('header', 'Circle')
@section('content')

{{-- Message --}}
<h1 class="text-center pt-4">Bootstrap Responsive accordion without JavScript By <a
        href="https://md-asaduzzaman-muhid.github.io/portfolio/" target="_blank" class="hover-1">Asaduzzaman</a></h1>

<div class="container">
    <div id="accordion" class="py-5">
        <div class="card border-0">
            <div class="card-header p-0 border-0" id="heading-239">
                <button class="btn btn-link accordion-title border-0 collapse" data-toggle="collapse"
                    data-target="#collapse-239" aria-expanded="true" aria-controls="#collapse-239"><i
                        class="fas fa-plus text-center d-flex align-items-center justify-content-center h-100"></i>lorem
                    header 1 </button>
            </div>
            <div id="collapse-239" class="collapse show" aria-labelledby="heading-239" data-parent="#accordion">
                <div class="card-body accordion-body">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
                        non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
        </div>
        <div class="card border-0 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <div class="card-header p-0 border-0" id="heading-240">
                <button class="btn btn-link accordion-title border-0 collapsed" data-toggle="collapse"
                    data-target="#collapse-240" aria-expanded="false" aria-controls="#collapse-240"><i
                        class="fas fa-plus text-center d-flex align-items-center justify-content-center h-100"></i>Is
                    there a 24/7 response for emergencies? </button>
            </div>
            <div id="collapse-240" class="collapse " aria-labelledby="heading-240" data-parent="#accordion">
                <div class="card-body accordion-body">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
                        non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
        </div>
        <div class="card border-0 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <div class="card-header p-0 border-0" id="heading-241">
                <button class="btn btn-link accordion-title border-0 collapsed" data-toggle="collapse"
                    data-target="#collapse-241" aria-expanded="false" aria-controls="#collapse-241"><i
                        class="fas fa-plus text-center d-flex align-items-center justify-content-center h-100"></i>How
                    are owners’ concerns handled? </button>
            </div>
            <div id="collapse-241" class="collapse " aria-labelledby="heading-241" data-parent="#accordion">
                <div class="card-body accordion-body">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
                        non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
        </div>
        <div class="card border-0 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <div class="card-header p-0 border-0" id="heading-242">
                <button class="btn btn-link accordion-title border-0 collapsed" data-toggle="collapse"
                    data-target="#collapse-242" aria-expanded="false" aria-controls="#collapse-242"><i
                        class="fas fa-plus text-center d-flex align-items-center justify-content-center h-100"></i>How
                    do I get repairs completed to my unit? </button>
            </div>
            <div id="collapse-242" class="collapse " aria-labelledby="heading-242" data-parent="#accordion">
                <div class="card-body accordion-body">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
                        non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
        </div>
        <div class="card border-0 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <div class="card-header p-0 border-0" id="heading-243">
                <button class="btn btn-link accordion-title border-0 collapsed" data-toggle="collapse"
                    data-target="#collapse-243" aria-expanded="false" aria-controls="#collapse-243"><i
                        class="fas fa-plus text-center d-flex align-items-center justify-content-center h-100"></i>What
                    are the duties of a property manager? </button>
            </div>
            <div id="collapse-243" class="collapse " aria-labelledby="heading-243" data-parent="#accordion">
                <div class="card-body accordion-body">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
                        non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
        </div>
        <div class="card border-0 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <div class="card-header p-0 border-0" id="heading-244">
                <button class="btn btn-link accordion-title border-0 collapsed" data-toggle="collapse"
                    data-target="#collapse-244" aria-expanded="false" aria-controls="#collapse-244"><i
                        class="fas fa-plus text-center d-flex align-items-center justify-content-center h-100"></i>Do we
                    receive copies of all invoices paid? </button>
            </div>
            <div id="collapse-244" class="collapse " aria-labelledby="heading-244" data-parent="#accordion">
                <div class="card-body accordion-body">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
                        non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
        </div>
        <div class="card border-0 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <div class="card-header p-0 border-0" id="heading-245">
                <button class="btn btn-link accordion-title border-0 collapsed" data-toggle="collapse"
                    data-target="#collapse-245" aria-expanded="false" aria-controls="#collapse-245"><i
                        class="fas fa-plus text-center d-flex align-items-center justify-content-center h-100"></i>How
                    are arrears handled? </button>
            </div>
            <div id="collapse-245" class="collapse " aria-labelledby="heading-245" data-parent="#accordion">
                <div class="card-body accordion-body">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
                        non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
        </div>
    </div>

</div>

<p class="text-center">With bootstrap, css and fontawesome accordion / FAQ design with sign without using any
    javascript. </p>
<p class="text-center">Don't forget to star, contribute & follow on <a href="https://github.com/Md-Asaduzzaman-Muhid"
        target="_blank" class="hover-1">Github</a></p>

@endsection