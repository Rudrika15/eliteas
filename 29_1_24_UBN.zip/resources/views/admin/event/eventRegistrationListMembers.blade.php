@extends('layouts.master')

@section('header', 'Event')
@section('content')


    <div class="container">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="card-title">Registraion List of {{ $event->title }} </h4>
                </div>

                <!-- Table with stripped rows -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Member Name</th>
                                <th>Visitor Name</th>
                                <th>Business Category</th>
                                <th>Business Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($registerLists as $registerListsData)
                                <tr>
                                    {{-- <th>{{ ($registerLists->currentPage() - 1) * $registerLists->perPage() + $loop->index + 1 }} --}}

                                    {{-- <td>{{ $registerListsData->events->title ?? '-' }}</td> --}}
                                    <td>{{ $registerListsData->members->firstName ?? '-' }}
                                        {{ $registerListsData->members->lastName ?? '-' }}
                                    </td>
                                    <td>{{ $registerListsData->personName ?? '-' }}</td>
                                    <td>{{ $registerListsData->members->bCategory->categoryName ?? '-' }}</td>
                                    <td>{{ $registerListsData->businessName ?? '-' }}</td>

                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-end custom-pagination">
                        {!! $registerList->links() !!}
                    </div>
                    <!-- End Table with stripped rows -->
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <script>
        $(document).ready(function() {
            $('.payment-status-dropdown').change(function() {
                const registerId = $(this).data('id');
                const paymentStatus = $(this).val();

                if (registerId) {
                    $.ajax({
                        url: '{{ route('updatePaymentStatus') }}', // Define the route in your web.php
                        type: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}', // Include CSRF token for security
                            id: registerId,
                            paymentStatus: paymentStatus,
                        },
                        success: function(response) {
                            if (response.success) {
                                Swal.fire({
                                    title: 'Success!',
                                    text: 'Payment status updated successfully.',
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                });
                            } else {
                                Swal.fire({
                                    title: 'Error!',
                                    text: 'Failed to update payment status.',
                                    icon: 'error',
                                    confirmButtonText: 'Try Again'
                                });
                            }
                        },
                        error: function(xhr) {
                            console.error(xhr);
                            Swal.fire({
                                title: 'Oops!',
                                text: 'An error occurred while updating payment status.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    });
                }
            });
        });
    </script>




@endsection
