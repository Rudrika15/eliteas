<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SupportTicket;
use App\Utils\Utils;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Utils\ErrorLogger;

class SupportTicketController extends Controller
{
    public function index(Request $request)
    {
        try {
            $tickets = SupportTicket::where('userId', Auth::id())
                ->orderByDesc('created_at')
                ->get();
            
            return Utils::sendResponse($tickets, 'Support tickets retrieved successfully.');
        } catch (\Throwable $th) {
            ErrorLogger::logError($th, request()->fullUrl());
            return Utils::errorResponses($th->getMessage(), 'Internal Server Error', 500);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'subject' => 'required|string|max:255',
            'description' => 'nullable|string',
            'priority' => 'required|in:Low,Medium,High',
            'attachment' => 'nullable|file|max:5120',
        ]);

        if ($validator->fails()) {
            return Utils::sendResponse(['errors' => $validator->errors()], 'Validation Error');
        }

        try {
            $ticket = new SupportTicket();
            $ticket->userId = Auth::id();
            $ticket->subject = $request->subject;
            $ticket->description = $request->description;
            $ticket->priority = $request->priority;
            $ticket->status = 'Open';

            if ($request->hasFile('attachment')) {
                $dir = public_path('support_attachments');
                if (!is_dir($dir)) {
                    @mkdir($dir, 0775, true);
                }
                $fileName = time() . '_' . $request->attachment->getClientOriginalName();
                $request->attachment->move($dir, $fileName);
                $ticket->attachment = $fileName;
            }

            $ticket->save();

            return Utils::sendResponse($ticket, 'Ticket created successfully.');
        } catch (\Throwable $th) {
            ErrorLogger::logError($th, request()->fullUrl());
            return Utils::errorResponses($th->getMessage(), 'Internal Server Error', 500);
        }
    }

    public function show($id)
    {
        try {
            $ticket = SupportTicket::where('id', $id)->where('userId', Auth::id())->first();

            if (!$ticket) {
                return Utils::errorResponses('Ticket not found or unauthorized access', 'Ticket not found', 404);
            }

            return Utils::sendResponse($ticket, 'Ticket retrieved successfully.');
        } catch (\Throwable $th) {
            ErrorLogger::logError($th, request()->fullUrl());
            return Utils::errorResponses($th->getMessage(), 'Internal Server Error', 500);
        }
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'subject' => 'required|string|max:255',
            'description' => 'nullable|string',
            'priority' => 'required|in:Low,Medium,High',
            'status' => 'required|in:Open,In Progress,Closed',
            'attachment' => 'nullable|file|max:5120',
        ]);

        if ($validator->fails()) {
            return Utils::sendResponse(['errors' => $validator->errors()], 'Validation Error');
        }

        try {
            $ticket = SupportTicket::where('id', $id)->where('userId', Auth::id())->first();

            if (!$ticket) {
                return Utils::errorResponses('Ticket not found or unauthorized access', 'Ticket not found', 404);
            }

            $ticket->subject = $request->subject;
            $ticket->description = $request->description;
            $ticket->priority = $request->priority;
            $ticket->status = $request->status;

            if ($request->hasFile('attachment')) {
                $dir = public_path('support_attachments');
                if (!is_dir($dir)) {
                    @mkdir($dir, 0775, true);
                }
                $fileName = time() . '_' . $request->attachment->getClientOriginalName();
                $request->attachment->move($dir, $fileName);
                $ticket->attachment = $fileName;
            }

            $ticket->save();

            return Utils::sendResponse($ticket, 'Ticket updated successfully.');
        } catch (\Throwable $th) {
            ErrorLogger::logError($th, request()->fullUrl());
            return Utils::errorResponses($th->getMessage(), 'Internal Server Error', 500);
        }
    }
}
