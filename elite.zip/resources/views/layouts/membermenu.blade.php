<li class="nav-item">
    <a class="nav-link " href="{{route('circlecall.index')}}">
        <i class="bi bi-mic"></i>
        <span>Circle Meeting 1:1</span>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link " href="{{route('refGiver.index')}}">
        <i class="bi bi-person"></i>
        <span>Reference Giver</span>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link " href="{{route('busGiver.index')}}">
        <i class="bi bi-person"></i>
        <span>Circle Member Business</span>
    </a>
</li>