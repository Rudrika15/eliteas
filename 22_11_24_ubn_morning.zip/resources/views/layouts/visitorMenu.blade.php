
<li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#event-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-calendar-check" style="color: #e76a35"></i><span>Event</span><i
            class="bi bi-chevron-down ms-auto" style="color: #e76a35"></i>
    </a>
    <ul id="event-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="{{ route('connection.connectionRequests') }}">
                <i class="bi bi-calendar-check" style="color: #e76a35"></i>
                <span>Slot Booking</span>
            </a>
        </li>
    </ul>
</li>
