@extends('layouts.master')

@section('header', 'Train Master')
@section('content')

    {{-- Message --}}
    @if (Session::has('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert">
                {{-- <i class="fa fa-times"></i> --}}
            </button>
            <strong>Success !</strong> {{ session('success') }}
        </div>
    @endif

    @if (Session::has('error'))
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert">
                {{-- <i class="fa fa-times"></i> --}}
            </button>
            <strong>Error !</strong> {{ session('error') }}
        </div>
    @endif

    <div class="card">
        <div class="card-body d-flex justify-content-between align-items-center">
            <h5 class="card-title">Edit Train Master</h5>
            <a href="{{ route('trainer.index') }}" class="btn btn-secondary btn-sm">BACK</a>
        </div>

        <!-- Floating Labels Form -->
        <form class="m-3 needs-validation" id="trainmasterForm" enctype="multipart/form-data" method="post"
            action="{{ route('trainer.update', $trainer->id) }}" novalidate>
            @csrf
            <input type="hidden" name="id" value="{{ $trainer->id }}">
            <div class="row">
                <div class="col-md-6">
                    <!-- Trainer selection -->
                    <div class="form-check">
                        <input class="form-check-input trainer-radio" type="radio" name="type" id="internal"
                            value="internalMember" checked={{ $trainer->type == 'internalMember' ? 'checked' : '' }}>
                        <label class="form-check-label" for="internalMember">Internal</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input trainer-radio" type="radio" name="type" id="external"
                            value="externalMember" {{ $trainer->type == 'externalMember' ? 'checked' : '' }}>
                        <label class="form-check-label" for="externalMember">External</label>
                    </div>

                    <!-- Member selection -->
                    <div class="member-list" id="memberListDropdownMember">
                        @include('InternalTrainer')
                        <input type="hiddden" name="trainerId" id="trainerId" value="{{ $trainer->userId }}">
                        <input type="text" class="form-control mt-3" id="trainerName" name="memberName"
                            placeholder="Select Member" readonly
                            value="{{ $trainer->user->firstName }} {{ $trainer->user->lastName }}">
                        <input type="text" class="form-control mt-3" id="trainerContact" name="contactNo"
                            placeholder="Contact No" readonly value="{{ $trainer->user->contactNo }}">
                        <input type="text" class="form-control mt-3" id="trainerEmail" name="email"
                            value="{{ $trainer->user->email }}" placeholder="Email" readonly>
                    </div>
                    {{-- <div class="externalTrainer" id="externalTrainer" name="externalTrainer">
                    <input type="hidden" name="externalTrainerId" id="externalTrainerId"> --}}
                    {{-- <input type="text" class="form-control mt-3" id="trainerNameExternal" name="trainerNameExternal"
                        placeholder="Trainer Name External"> --}}
                    {{--
                </div> --}}

                    <!-- Contact details -->
                </div>
            </div>

            {{-- external Trainers Details --}}



            <div class="row mb-3 externalTrainer">
                <br>
                <b>External Trainer Details</b>
                <div class="col-md-6">
                    <div class="form-floating mt-3">
                        <input type="text" class="form-control @error('firstName') is-invalid @enderror" id="firstName"
                            name="firstName" placeholder="Train Name" value="{{ $trainer->user->firstName }}">
                        <label for="firstName">First Name</label>
                        @error('firstName')
                            <div class="invalid-tooltip">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mt-3">
                        <input type="text" class="form-control @error('lastName') is-invalid @enderror" id="lastName"
                            name="lastName" placeholder="Train Name" value="{{ $trainer->user->lastName }}">
                        <label for="lastName">Last Name</label>
                        @error('lastName')
                            <div class="invalid-tooltip">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mt-3">
                        <input type="text" class="form-control @error('email') is-invalid @enderror" id="email"
                            name="email" placeholder="Train Name" value="{{ $trainer->user->email }}">
                        <label for="email">Email</label>
                        @error('email')
                            <div class="invalid-tooltip">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mt-3">
                        <input type="text" class="form-control @error('contactNo') is-invalid @enderror" id="contactNo"
                            name="contactNo" placeholder="Contact No" value="{{ $trainer->user->contactNo }}">
                        <label for="contactNo">Contact No</label>
                        @error('contactNo')
                            <div class="invalid-tooltip">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mt-3">
                        <input type="file" class="form-control @error('trainerImage') is-invalid @enderror"
                            id="trainerImage" name="trainerImage" placeholder="Trainer Image" accept=".jpg, .jpeg, .png"
                            onchange="handleFileSelect(event)">
                        <label for="trainerImage">Trainer Image</label>
                        <img id="previewImage" src="{{ asset('trainerImage/' . $trainer->trainerImage) }}"
                            onerror="this.src='{{ asset('img/default.png') }}'" class="mt-2" width="100px"
                            height="100px" style="display: block;">
                        <span class="text-danger">* Image size must be maximum 2MB</span>
                        @error('trainerImage')
                            <div class="invalid-tooltip" style="color:red">
                                {{ $message }} <br>
                                * Image size must be maximum 2MB
                            </div>
                        @enderror
                    </div>
                </div>

                <script>
                    function handleFileSelect(event) {
                        var input = event.target;
                        var preview = document.getElementById('previewImage');

                        // Validate image size
                        let fileSize = input.files[0] ? input.files[0].size / 1024 / 1024 : 0;
                        if (fileSize > 2) {
                            input.setCustomValidity('Image size must be maximum 2MB');
                            input.reportValidity();
                            // Reset input if size is invalid
                            input.value = '';
                            preview.src = '{{ asset('img/profile.png') }}'; // Reset to default image
                            return;
                        } else {
                            input.setCustomValidity('');
                        }

                        // Preview image
                        if (input.files && input.files[0]) {
                            var reader = new FileReader();
                            reader.onload = function() {
                                var dataURL = reader.result;
                                preview.src = dataURL; // Update preview with new image
                            };
                            reader.readAsDataURL(input.files[0]);
                        }
                    }
                </script>



            </div>
            <div class="text-center mt-5">
                <button type="submit" class="btn btn-primary">Submit</button>
                {{-- <button type="reset" class="btn btn-secondary">Reset</button> --}}
            </div>
        </form><!-- End floating Labels Form -->
    </div>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <script>
        $(document).ready(function() {
            $('.externalTrainer').hide();

            $('.trainer-radio').change(function() {
                var selectedVal = $(this).val();

                if (selectedVal == 'externalMember') {
                    $('.member-list').hide();
                    $('.externalTrainer').show();
                } else {
                    $('.member-list').show();
                    $('.externalTrainer').hide();
                }
            });
        });
    </script>

@endsection
