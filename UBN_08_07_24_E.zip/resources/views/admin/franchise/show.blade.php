<div class="card">
    <div class="card-body">
        <h5 class="card-title">Franchise</h5>

        <!-- Table with stripped rows -->

        <!-- End Table with stripped rows -->

    </div>