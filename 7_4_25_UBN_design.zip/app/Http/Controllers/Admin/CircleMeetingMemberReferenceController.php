<?php

namespace App\Http\Controllers\Admin;


use Carbon\Carbon;
use App\Models\Circle;
use App\Models\Member;
use App\Utils\ErrorLogger;
use Illuminate\Http\Request;
use App\Models\CircleMeeting;
use Illuminate\Support\Facades\URL;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\CircleMeetingMembersBusiness;
use App\Models\CircleMeetingMembersReference;

class CircleMeetingMemberReferenceController extends Controller
{

    public function __construct()
    {
        // Apply middleware for circle call-related permissions
        $this->middleware('permission:circle-meeting-member-reference-index', ['only' => ['index', 'view']]);
        $this->middleware('permission:circle-meeting-member-reference-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:circle-meeting-member-reference-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:circle-meeting-member-reference-delete', ['only' => ['delete']]);
        $this->middleware('permission:get-member-details', ['only' => ['getMemberDetails']]);
    }


    public function index(Request $request)
    {
        try {
            $refGiver = CircleMeetingMembersReference::where('status', 'Active')
                ->orderBy('id', 'DESC')
                ->with('members')
                ->with('refGiverName')
                ->where('referenceGiverId', Auth::user()->id)
                ->paginate(10);

            // $referenceByOther = CircleMeetingMembersReference::where('status', 'Active')
            //     ->orderBy('id', 'DESC')
            //     ->with('members')
            //     ->with('refGiverName')
            //     ->where('memberId', Auth::user()->id)
            //     ->paginate(10);

            $busGiver = CircleMeetingMembersBusiness::where('loginMemberId', Auth::user()->id)
                ->where('status', 'Active')
                ->orderBy('id', 'DESC')
                ->paginate(10);

            return view('admin.refGiver.index', compact('refGiver', 'busGiver'));
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError(
                $th,
                $request->fullUrl()
            );
            return view('servererror');
        }
    }
    //For show single data
    public function view(Request $request, $id)
    {
        try {
            $refGiver = CircleMeetingMembersReference::findOrFail($id);
            return response()->json($refGiver);
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError(
                $th,
                $request->fullUrl()
            );
            return view('servererror');
        }
    }
    public function create(Request $request)
    {
        try {

            $circles = Circle::where('status', 'Active')->get();

            $circleMember = Member::with('circle')
                ->where('status', 'Active')
                ->get(); // Ensure 'circleId' is included


            $circlemeeting = CircleMeeting::where('status', 'Active')->get();
            // $members = Member::where('status', 'Active')->get();
            return view('admin.refGiver.create', compact('circlemeeting', 'circles', 'circleMember'));
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError(
                $th,
                $request->fullUrl()
            );
            return view('servererror');
        }
    }

    public function refByOther(Request $request)
    {
        try {

            $circles = Circle::where('status', 'Active')->get();

            $circleMember = Member::with('circle')
                ->where('status', 'Active')
                ->get();


            $circlemeeting = CircleMeeting::where('status', 'Active')->get();
            // $members = Member::where('status', 'Active')->get();
            return view('admin.refGiver.refByOther', compact('circlemeeting', 'circles', 'circleMember'));
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError(
                $th,
                $request->fullUrl()
            );
            return view('servererror');
        }
    }

    public function getMemberDetails(Request $request)
    {
        $memberName = $request->input('memberName');

        // Assuming you have a Member model and 'email' and 'contactNo' fields in your database table
        $member = Member::where('firstName', $memberName)->first();

        return response()->json([
            'email' => $member->email,
            'contactNo' => $member->contactNo,
        ]);
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            // 'dateTime' => 'required',
            // 'totalMeeting' => 'required',
            // 'refGiven' => 'required',
            // 'refTaken' => 'required',
            // 'busGiven' => 'required',
            // 'busTaken' => 'required',
            // 'hotelName' => 'required',
        ]);


        // return $request;
        try {
            $refGiver = new CircleMeetingMembersReference();

            $refGiver->referenceGiverId = Auth::user()->id;
            $refGiver->memberId = $request->memberId;

            if ($request->group == 'internal')
                $refGiver->contactName = $request->contactNameInternal;
            else
                $refGiver->contactName = $request->contactNameExternal;

            $refGiver->contactNo = $request->contactNo;
            $refGiver->email = $request->email;
            $refGiver->scale = $request->scale;
            $refGiver->description = $request->description;
            $refGiver->status = 'Active';

            $refGiver->save();


            $busGiver = new CircleMeetingMembersBusiness();
            // $busGiver->memberId = $request->memberId;
            $busGiver->businessGiverId = Auth::user()->id;
            $busGiver->loginMemberId = $refGiver->memberId;
            $busGiver->amount = $request->amount;
            $busGiver->date = Carbon::now()->toDateString();
            $busGiver->status = 'Active';
            $busGiver->save();

            return redirect()->route('refGiver.index')->with('success', ' Created Successfully!');
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError(
                $th,
                $request->fullUrl()
            );
            return view('servererror');
        }
    }

    public function refByOtherStore(Request $request)
    {
        $this->validate($request, [
            // 'dateTime' => 'required',
            // 'totalMeeting' => 'required',
            // 'refGiven' => 'required',
            // 'refTaken' => 'required',
            // 'busGiven' => 'required',
            // 'busTaken' => 'required',
            // 'hotelName' => 'required',
        ]);


        // return $request;
        try {
            $refGiver = new CircleMeetingMembersReference();

            $refGiver->referenceGiverId = $request->memberId;
            $refGiver->memberId = Auth::user()->id;

            if ($request->group == 'internal')
                $refGiver->contactName = $request->contactNameInternal;
            else
                $refGiver->contactName = $request->contactNameExternal;

            $refGiver->contactNo = $request->contactNo;
            $refGiver->email = $request->email;
            $refGiver->scale = $request->scale;
            $refGiver->description = $request->description;
            $refGiver->status = 'Active';

            $refGiver->save();


            $busGiver = new CircleMeetingMembersBusiness();
            // $busGiver->memberId = $request->memberId;
            $busGiver->businessGiverId = $refGiver->referenceGiverId;
            $busGiver->loginMemberId = Auth::user()->id;
            // $busGiver->loginMemberId = Auth::user()->id;
            $busGiver->amount = $request->amount;
            $busGiver->remarks = $request->remarks;
            $busGiver->date = Carbon::now()->toDateString();
            $busGiver->status = 'Active';
            $busGiver->save();

            return redirect()->route('refGiver.index')->with('success', ' Created Successfully!');
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError(
                $th,
                $request->fullUrl()
            );
            return view('servererror');
        }
    }

    public function edit(Request $request, $id)
    {
        try {
            $refGiver = CircleMeetingMembersReference::find($id);
            $member = Member::where('status', 'Active')->get();
            $circles = Circle::where('status', 'Active')->get();

            return view('admin.refGiver.edit', compact('refGiver', 'member', 'circles'));
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError(
                $th,
                $request->fullUrl()
            );
            return view('servererror');
        }
    }

    public function update(Request $request)
    {
        $this->validate($request, [
            // 'dateTime' => 'required',
            // 'totalMeeting' => 'required',
            // 'refGiven' => 'required',
            // 'refTaken' => 'required',
            // 'busGiven' => 'required',
            // 'busTaken' => 'required',
            // 'hotelName' => 'required',

        ]);
        try {
            // return $id;
            $id = $request->id;
            $refGiver = CircleMeetingMembersReference::find($id);


            $refGiver->memberId = $request->memberId;

            // $refGiver->referenceGiver = $request->referenceGiver;
            $refGiver->contactName = $request->contactNameExternal;
            $refGiver->contactNo = $request->contactNo;
            $refGiver->email = $request->email;
            $refGiver->scale = $request->scale;
            $refGiver->description = $request->description;
            $refGiver->status = 'Active';

            $refGiver->save();
            return redirect()->route('refGiver.index')->with('success', ' Updated Successfully!');
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError(
                $th,
                $request->fullUrl()
            );
            return view('servererror');
        }
    }

    function delete(Request $request, $id)
    {
        try {
            $refGiver = CircleMeetingMembersReference::find($id);
            $refGiver->status = "Deleted";
            $refGiver->save();

            return redirect()->route('refGiver.index')->with('success', ' Deleted Successfully!');
        } catch (\Throwable $th) {
            // throw $th;
            ErrorLogger::logError(
                $th,
                $request->fullUrl()
            );
            return view('servererror');
        }
    }
}
