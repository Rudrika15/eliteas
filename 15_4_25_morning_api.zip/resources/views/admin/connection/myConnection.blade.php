@extends('layouts.master')

@section('title', 'UBN - My Connections')

@section('content')
    <style>
        .page-header {
            padding: 1rem 2rem;
            background-color: #fff;
            border-radius: 10px;
            margin-bottom: 1.5rem;
        }

        .tab-count {
            color: #e76a35;
            font-weight: 500;
        }

        .connection-card {
            background-color: #fff;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: 0.3s;
            margin-bottom: 2rem;
        }

        .connection-card:hover {
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .card-header-image {
            width: 100%;
            height: 90px;
            object-fit: cover;
        }

        .card-body {
            text-align: center;
            padding: 1rem;
        }

        .profile-img {
            width: 70px;
            height: 70px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid white;
            margin-top: -35px;
        }

        .name {
            font-weight: bold;
            font-size: 16px;
            color: #1d3268;
            margin-top: 0.5rem;
        }

        .position {
            font-size: 14px;
            color: #6c757d;
        }

        .connected {
            color: #e76a35;
            font-weight: 500;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #6c757d;
            padding: 0.25rem 1rem;
        }

        .detail-label {
            font-weight: 600;
            color: #1d3268;
        }

        .action-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 1rem;
            padding: 0 1rem 1rem;
        }

        .btn-orange {
            background-color: #e76a35;
            color: white;
            font-size: 13px;
            border: none;
            border-radius: 10px;
            padding: 5px 10px;
        }

        .btn-orange:hover {
            background-color: #cf5f2f;
        }

        .ubn-tab-nav {
            border-bottom: 1px solid #e0e0e0;
            padding-bottom: 0;
            gap: 30px;
        }

        .ubn-tab-nav .nav-link {
            font-size: 16px;
            font-weight: 600;
            color: #2f3a59;
            border: none;
            background-color: transparent;
            padding: 12px 0;
            position: relative;
        }

        .ubn-tab-nav .nav-link.active {
            color: #e76a35;
            font-weight: 700;
        }

        .ubn-tab-nav .nav-link.active::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 100%;
            height: 3px;
            background-color: #e76a35;
            border-radius: 2px;
        }

        .ubn-tab-nav .nav-link:hover {
            color: #e76a35;
            background-color: transparent;
        }

        .ubn-tab-nav .count {
            color: #e76a35;
            font-weight: 500;
        }

        
    </style>

    <!-- Tabs -->
    <ul class="nav nav-tabs ubn-tab-nav justify-content-start mb-4 px-2" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link active" data-target="tab-my-connections" href="javascript:void(0);">
                My Connection <span class="count">({{ is_countable($connections ?? []) ? count($connections ?? []) : 0 }})</span>
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" data-target="tab-sent-requests" href="javascript:void(0);">
                Sent Connection Request <span class="count">({{ is_countable($sentRequests ?? []) ? count($sentRequests ?? []) : 0 }})</span>
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" data-target="tab-received-requests" href="javascript:void(0);">
                Received Connection Request <span class="count">({{ is_countable($receivedRequests ?? []) ? count($receivedRequests ?? []) : 0 }})</span>
            </a>
        </li>
    </ul>





    <!-- Search -->
    {{-- <div class="search-input">
            <a href="{{ route('search') }}" class="w-100">
                <input type="text" placeholder="Click Here to Go for Search Member" title="Enter search keyword" readonly />
            </a>
        </div> --}}

    <!-- Connection Cards -->
    {{-- <div class="tab-content">
        <!-- My Connections -->
        <div id="tab-my-connections" class="tab-pane row">
            @forelse ($connections as $connection)
                <div class="col-md-4 mb-4">
                    <div class="profile-card">
                        <img src="https://picsum.photos/600/120" class="header-image">
                        <div class="text-center p-3">
                            <img src="{{ asset($connection->connectedUser->profilePicture ?? 'img/profile.png') }}" class="profile-img">
                            <h5 class="profile-name">
                                {{ $connection->connectedUser->firstName ?? 'N/A' }} {{ $connection->connectedUser->lastName ?? 'N/A' }}
                            </h5>
                            <p class="profile-details"><span class="badge bg-success">Connected</span></p>
                            <a href="#" class="btn btn-sm btn-outline-danger mt-2">Remove Connection</a>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center text-muted">No connections found</div>
            @endforelse
        </div>

        <!-- Sent Requests -->
        <div id="tab-sent-requests" class="tab-pane row d-none">
            @forelse ($sentRequests as $request)
                <div class="col-md-4 mb-4">
                    <div class="profile-card">
                        <div class="text-center p-3">
                            <img src="{{ asset($request->receiverMember->profilePhoto ?? 'img/profile.png') }}" class="profile-img">
                            <h5 class="profile-name">
                                {{ $request->receiver->firstName ?? 'N/A' }} {{ $request->receiver->lastName ?? 'N/A' }}
                            </h5>
                            <p class="profile-details"><span class="badge bg-warning">Request Sent</span></p>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center text-muted">No sent requests found</div>
            @endforelse
        </div>

        <!-- Received Requests -->
        <div id="tab-received-requests" class="tab-pane row d-none">
            @forelse ($receivedRequests as $request)
                <div class="col-md-4 mb-4">
                    <div class="profile-card">
                        <div class="text-center p-3">
                            <img src="{{ asset($request->member->profilePhoto ?? 'img/profile.png') }}" class="profile-img">
                            <h5 class="profile-name">
                                {{ $request->member->firstName ?? 'N/A' }} {{ $request->member->lastName ?? 'N/A' }}
                            </h5>
                            <p class="profile-details"><span class="badge bg-info">Request Received</span></p>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center text-muted">No received requests found</div>
            @endforelse
        </div>
    </div> --}}


    {{-- <script>
        document.querySelectorAll('.ubn-tab-nav .nav-link').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.ubn-tab-nav .nav-link').forEach(t => t.classList.remove('active'));
                this.classList.add('active');

                const target = this.dataset.target;
                document.querySelectorAll('.tab-pane').forEach(pane => {
                    pane.classList.add('d-none');
                    pane.classList.remove('active');
                });
                document.getElementById(target).classList.remove('d-none');
                document.getElementById(target).classList.add('active');
            });
        });
    </script> --}}

    <!-- Simple Tab Switch Script -->
    <script>
        document.querySelectorAll('.nav-link[data-target]').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
                this.classList.add('active');

                const target = this.getAttribute('data-target');
                document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.add('d-none'));
                document.getElementById(target).classList.remove('d-none');
            });
        });
    </script>



@endsection
