<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VisitorRegisteredMail extends Mailable
{
    use Queueable, SerializesModels;

    public $visitor;
    public $event;

    /**
     * Create a new message instance.
     *
     * @param $visitor
     * @param $event
     */
    public function __construct($visitor, $event)
    {
        $this->visitor = $visitor;
        $this->event = $event;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Thank You for Registering!')
            ->view('email.eventRegistrationOther')
            ->with([
                'visitor' => $this->visitor,
                'event' => $this->event,
            ]);
    }
}
