<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profile Card Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .profile-card {
            width: 320px;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.08);
            background-color: #fff;
            margin: 40px auto;
        }

        .header-image {
            width: 100%;
            height: 100px;
            object-fit: cover;
        }

        .profile-img {
            width: 90px;
            height: 90px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid #fff;
            margin-top: -45px;
        }

        .icon-text {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            font-size: 13px;
        }

        .icon-text i {
            font-size: 20px;
            color: #5f6368;
            margin-bottom: 4px;
        }

        .company-name {
            font-weight: 600;
            margin-bottom: 2px;
        }

        .category-text {
            color: #888;
            font-size: 13px;
            margin-bottom: 8px;
        }

        .keyword-btn {
            border-radius: 50px;
            font-size: 12px;
            padding: 4px 12px;
            background-color: #f1f1f1;
            border: none;
            margin: 4px;
        }

        .profile-actions {
            border-top: 1px solid #f0f0f0;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .profile-actions a {
            text-decoration: none;
            font-weight: 500;
        }

        .btn-message {
            background-color: #ff6b6b;
            color: white;
            border-radius: 50px;
            padding: 6px 14px;
            border: none;
        }
    </style>
</head>

<body>
    <div class="profile-card">
        <img src="https://picsum.photos/600/100" class="header-image" alt="Header Image">
        <div class="text-center p-3">
            <img src="https://randomuser.me/api/portraits/men/75.jpg" class="profile-img" alt="Profile">
            <h5 class="mt-2 mb-0">John Doshi</h5>
            <p class="text-muted mb-2" style="font-size: 14px;">Vice President at UBN</p>
            <div class="d-flex justify-content-around text-center mt-3 mb-3">
                <div class="icon-text">
                    <i class="bi bi-envelope-fill"></i>
                    <div>John5968dosh...</div>
                </div>
                <div class="icon-text">
                    <i class="bi bi-telephone-fill"></i>
                    <div>941 440 2140</div>
                </div>
                <div class="icon-text">
                    <i class="bi bi-people-fill"></i>
                    <div>Pinnacle</div>
                </div>
            </div>
            <div class="text-center">
                <div class="company-name">CubX Technologies</div>
                <div class="category-text">Category: Mechanical Workshop</div>
                <div>
                    <button class="keyword-btn">Keyword 1</button>
                    <button class="keyword-btn">Keyword 2</button>
                    <button class="keyword-btn">Keyword 3</button>
                </div>
            </div>
        </div>
        <div class="profile-actions">
            <a href="#">View Profile</a>
            <button class="btn-message">Message</button>
        </div>
    </div>
</body>

</html>
