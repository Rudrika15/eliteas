@extends('layouts.master')

@section('header', 'Franchise')
@section('content')

    {{-- Message --}}
    {{-- @if (Session::has('success'))
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Success!</strong> {{ session('success') }}
</div>
@endif

@if (Session::has('error'))
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Error!</strong> {{ session('error') }}
</div>
@endif --}}

    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="card-title">Franchise</h4>
                <a href="{{ route('franchise.create') }}" class="btn btn-bg-orange btn-sm mt-3 btn-tooltip"><i
                        class="bi bi-plus-circle"></i>
                    <span class="btn-text">Add Franchise</span>
                </a>
            </div>

            <!-- Table with stripped rows -->
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Franchise Name</th>
                            <th>Owner Name</th>
                            <th>City Name</th>
                            <th>Franchise Contact Details</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($franchises as $franchiseData)
                            <tr>
                                {{-- <td>{{$loop->index + 1}}</td> --}}
                                <th>{{ ($franchises->currentPage() - 1) * $franchises->perPage() + $loop->index + 1 }}

                                <td>{{ $franchiseData->franchiseName }}</td>
                                <td>{{ $franchiseData->user ? $franchiseData->user->firstName . ' ' . $franchiseData->user->lastName : 'Managed By UBN' }}
                                </td>
                                <td>{{ $franchiseData->city->cityName ?? '-' }}</td>
                                <td>{{ $franchiseData->franchiseContactDetails ?? '9979411148' }}</td>
                                <td>{{ $franchiseData->status }}</td>
                                <td>
                                    {{-- <div class="btn-group" role="group"> --}}
                                    <a href="{{ route('franchise.edit', $franchiseData->id) }}"
                                        class="btn btn-bg-blue btn-sm btn-tooltip">
                                        <i class="bi bi-pen"></i>
                                        <span class="btn-text">Edit Franchise</span>
                                    </a>

                                    {{-- <a href="{{ route('franchise.show', $franchiseData->id) }}" class="btn btn-info">
                                    <i class="bi bi-eye"></i>
                                </a> --}}

                                    <a href="{{ route('franchise.delete', $franchiseData->id) }}"
                                        class="btn btn-danger btn-sm btn-tooltip justify-content-center align-items-center"
                                        onclick="event.preventDefault();deleteFranchise(this);">
                                        <i class="bi bi-trash"></i>
                                        <span class="btn-text">Delete</span>
                                    </a>

                                    <script>
                                        function deleteFranchise(element) {
                                            Swal.fire({
                                                title: 'Are you sure?',
                                                text: "Do you want to delete this franchise?",
                                                icon: 'warning',
                                                showCancelButton: true,
                                                confirmButtonColor: '#3085d6',
                                                cancelButtonColor: '#d33',
                                                confirmButtonText: 'Yes, delete it!'
                                            }).then((result) => {
                                                if (result.isConfirmed) {
                                                    window.location.href = element.href;
                                                    Swal.fire(
                                                        'Deleted!',
                                                        'Franchise has been Deleted.',
                                                        'success'
                                                    )
                                                }
                                            })
                                        }
                                    </script>


                                    {{--
                            </div> --}}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="d-flex justify-content-end custom-pagination">
                    {!! $franchises->links() !!}
                </div>
            </div>
            <!-- End Table with stripped rows -->
        </div>
    </div>

@endsection
