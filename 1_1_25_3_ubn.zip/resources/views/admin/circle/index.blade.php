@extends('layouts.master')

@section('header', 'Circle')
@section('content')

    {{-- Message --}}
    {{-- @if (Session::has('success'))
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Success !</strong> {{ session('success') }}
</div>
@endif

@if (Session::has('error'))
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong>Error !</strong> {{ session('error') }}
</div>
@endif --}}

    <div class="container ">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="card-title">Circle</h4>
                    <div class="">
                        <a href="{{ route('circle.create') }}" class="btn btn-bg-orange btn-sm mt-3 mr-2 btn-tooltip"><i
                                class="bi bi-plus-circle"></i>
                            <span class="btn-text">Create Circle</span></a>
                        @role('Admin')
                            <a href="{{ route('schedule.index') }}" class="btn btn-bg-blue btn-sm mt-3">All Meetings</a>
                        @endrole
                    </div>
                </div>


                <!-- Table with stripped rows -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Created By</th>
                                <th>Circle Name</th>
                                <th>Franchise Name</th>
                                <th>City Name</th>
                                <th>Circle Type</th>
                                <th>Meeting Day</th>
                                {{-- <th>Meeting Time</th> --}}
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($circle as $circleData)
                                <tr>
                                    <th>{{ ($circle->currentPage() - 1) * $circle->perPage() + $loop->index + 1 }}</th>
                                    <td>{{ $circleData->users->firstName ?? '' }} {{ $circleData->users->lastName ?? '' }}
                                    </td>
                                    <td>{{ $circleData->circleName }}</td>
                                    <td>{{ $circleData->franchise->franchiseName ?? '-' }}</td>
                                    <td>{{ $circleData->city->cityName ?? '-' }}</td>
                                    <td>{{ $circleData->circletype->circleTypeName ?? '-' }}</td>
                                    <td>
                                        {{-- Display name based on meeting day --}}
                                        @if ($circleData->meetingDay == 0)
                                            Sunday
                                        @elseif($circleData->meetingDay == 1)
                                            Monday
                                        @elseif($circleData->meetingDay == 2)
                                            Tuesday
                                        @elseif($circleData->meetingDay == 3)
                                            Wednesday
                                        @elseif($circleData->meetingDay == 4)
                                            Thursday
                                        @elseif($circleData->meetingDay == 5)
                                            Friday
                                        @elseif($circleData->meetingDay == 6)
                                            Saturday
                                        @else
                                            -
                                        @endif
                                    </td>
                                    {{-- <td>{{$circleData->meetingTime}}</td> --}}
                                    <td>{{ $circleData->status }}</td>
                                    <td>

                                        <a href="{{ route('circle.report', $circleData->id) }}"
                                            class="btn btn-bg-blue btn-sm btn-tooltip">
                                            <i class="bi bi-file-earmark-text"></i>
                                            <span class="btn-text">Circle Report</span>
                                        </a>


                                        <a href="{{ route('meetings.by.circle', $circleData->id) }}"
                                            class="btn btn-bg-orange btn-sm btn-tooltip">
                                            <i class="bi bi-eye"></i>
                                            <span class="btn-text">View Circle Meetings</span>
                                        </a>

                                        <a href="{{ route('circle.edit', $circleData->id) }}"
                                            class="btn btn-bg-blue btn-sm btn-tooltip">
                                            <i class="bi bi-pen"></i>
                                            <span class="btn-text">Edit</span>
                                        </a>

                                        <a href="{{ route('circle.memberList', $circleData->id) }}"
                                            class="btn btn-info btn-sm btn-tooltip">
                                            <i class="bi bi-person-lines-fill"></i>
                                            <span class="btn-text">View Members</span>
                                        </a>

                                        <a href="{{ route('circle.delete', $circleData->id) }}"
                                            class="btn btn-danger btn-sm btn-tooltip">
                                            <i class="bi bi-trash"></i>
                                            <span class="btn-text">Delete</span>
                                        </a>

                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-end custom-pagination">
                        {!! $circle->links() !!}
                    </div>
                </div>
                <!-- End Table with stripped rows -->
            </div>
        </div>
    </div>
@endsection
