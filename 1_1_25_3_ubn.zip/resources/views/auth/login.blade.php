<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            height: 100vh;
            font-family: 'Arial', sans-serif;
            overflow: hidden;
        }

        .left-section {
            background-color: #1C2956;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .left-section h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        .left-section p {
            margin-top: 20px;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
        }

        .left-section img {
            max-width: 100%;
        }

        .form-container img {
            display: block;
            margin: 0 auto 20px;
            max-width: 150px;
        }

        .form-group .form-control {
            padding-left: 0px;
            border-radius: 0;
            border: none;
            border-bottom: 1px solid #ccc;
            width: 50%;
            margin: 0 auto;
            margin-top: 20px;
            color: #1C2956;
            font-weight: bold;
        }

        .form-group .icon {
            position: absolute;
            top: 50%;
            left: 410px;
            transform: translateY(-50%);
            color: #1C2956;
        }

        .form-container a {
            text-align: right;
            display: block;
            font-size: 14px;
            color: #1A2E58;
            text-decoration: none;
        }

        .form-container a:hover {
            text-decoration: underline;
        }

        .btn-login {
            background-color: #1A2E58;
            color: #ffffff;
            border-radius: 5px;
        }

        .btn-login:hover {
            background-color: #143a6a;
        }

        .footer {
            text-align: center;
            font-size: 12px;
            color: #666;
            margin-top: 20px;
        }

        .graph-image {
            margin-top: 100px !important;
            height: 500px;
        }

        .globe-overlay {
            position: absolute;
            top: -80px;
            right: -100px;
            z-index: 10;
            /* Ensures it overlays other elements */
            width: 300px;
            /* Adjust width */
            height: auto;
            pointer-events: none;
            /* Prevents blocking clicks */
            opacity: 50%;
        }

        /* Media Queries for Mobile */
        @media (max-width: 767px) {
            .left-section {
                display: none;
            }

            .form-container img {
                max-width: 100px;
            }

            .form-group .form-control {
                width: 80%;
            }

            .btn-login {
                width: 80%;
            }
        }
    </style>
</head>

<body>
    <div class="container-fluid h-100">
        <div class="row h-100">
            <!-- Left Section -->
            <div class="col-md-5 d-flex align-items-center justify-content-center left-section d-none d-md-flex">
                <div class="text-center mt-5 graph-image">
                    <img src="{{ asset('img/ubnGraph1.png') }}" alt="UBN" class="">
                </div>
            </div>
            <div class="rounded-pill position-absolute w-25 " style="background: white; color: #1C2956; margin-left: 400px;  padding: 10px; border: none; margin-top: 60px">
                <button class="bg-transparent border-0 ms-2">
                    <h1 class="fw-bold mb-0" style="color: #1C2956;">Login</h1>
                </button>
            </div>
            <!-- Right Section -->
            <div class="col-md-7 col-12 d-flex align-items-center justify-content-center">
                <div class="form-container w-75">
                    <img src="{{ asset('img/logo2.jpg') }}" alt="UBN" class="mb-3">

                    <form method="POST" action="{{ route('login') }}" class="needs-validation w-100" novalidate id="login-form">
                        @csrf
                        <!-- Email Field -->
                        <div class="form-group position-relative mb-3">
                            <input id="email" type="email" class="form-control border-none @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Email">
                            <span class="icon position-absolute">&#9993;</span>

                            @if (Session::has('error') && Session::get('error') === 'email')
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong>Your Email is incorrect.</strong>
                                </span>
                            @endif

                            @error('email')
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <!-- Password Field -->
                        <div class="form-group position-relative mb-3">
                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password" placeholder="Password">
                            <span class="icon position-absolute">&#128274;</span>

                            @if (Session::has('error') && Session::get('error') === 'password')
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong>Your Password is incorrect.</strong>
                                </span>
                            @endif

                            @error('password')
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <!-- Forgot Password -->
                        @if (Route::has('password.request'))
                            <a href="{{ route('forget.password.get') }}" class="d-block mb-3" style="color: #1d3268; font-weight: bold; margin-right: 145px">
                                Forgot Your Password?
                            </a>
                        @endif

                        <!-- Login Button -->
                        <div class="d-flex justify-content-center align-items-center">
                            <button type="submit" class="btn btn-login w-30 rounded-pill">Login</button>
                        </div>

                        <!-- Hidden Latitude and Longitude Fields -->
                        <input type="hidden" name="latitude" id="latitude">
                        <input type="hidden" name="longitude" id="longitude">
                    </form>

                    <!-- Footer -->
                    <div class="footer mt-3">Designed by Aspireotech Solutions</div>
                </div>
            </div>
        </div>

        <!-- Globe Image Overlay -->
        <img src="{{ asset('img/loginDesign.png') }}" alt="Network Globe" class="globe-overlay">
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
