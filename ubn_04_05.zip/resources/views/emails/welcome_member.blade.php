@component('mail::message')
# Welcome to UBN

Your username is: {{ $username }}

Your password is: {{$password}}

Please keep this information secure.

Thank you,
The UBN Team
@endcomponent