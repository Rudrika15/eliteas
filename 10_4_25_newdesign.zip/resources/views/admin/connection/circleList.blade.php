@extends('layouts.master')
@section('content')
    <div class="container-fluid mt-4">
        <div class="row">
            <!-- Left: Circle List (col-md-3) -->
            <div class="col-md-3">
                <!-- My Circle Section -->
                <div class="bg-light rounded p-3 mb-3">
                    <h6 class="fw-semibold text-muted mb-3">My Circle</h6>
                    @if ($authCircle)
                        <div class="d-flex justify-content-between align-items-center bg-white rounded shadow-sm p-2 mb-2" style="cursor: pointer;">
                            <div class="d-flex align-items-center gap-2">
                                <img src="{{ asset($authCircle->profilePicture ?? 'img/logo2.jpg') }}" class="rounded-circle" width="40" height="40" alt="{{ $authCircle->circleName }}">
                                <div>
                                    <div class="fw-semibold">{{ $authCircle->circleName }}</div>
                                    <small class="text-muted">{{ $authCircle->city->cityName ?? 'N/A' }}</small>
                                </div>
                            </div>
                            <div class="text-end">
                                <div class="fw-semibold text-primary">₹ {{ number_format($authCircle->totalBusinessAmount ?? 0, 0) }}</div>
                                <small class="text-muted">👥 {{ $authCircle->members_count }}</small>
                            </div>
                        </div>
                    @else
                        <p class="text-muted small">You are not part of any circle yet.</p>
                    @endif
                </div>

                <!-- Filters -->
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <small class="text-muted">All Circle ({{ $circles->count() }})</small>
                    <select class="form-select form-select-sm w-50">
                        <option selected>All City</option>
                        @foreach ($circles->pluck('city.cityName')->unique() as $cityName)
                            <option>{{ $cityName }}</option>
                        @endforeach
                    </select>
                </div>

                <!-- All Circles -->
                <div class="circle-list">
                    @foreach ($circles->take(8) as $index => $circle)
                        <div class="d-flex justify-content-between align-items-center bg-white rounded shadow-sm p-2 mb-2" data-id="{{ $circle->id }}" style="cursor: pointer;">
                            <div class="d-flex align-items-center gap-2">
                                <span class="fw-bold text-muted">{{ $index + 1 }}.</span>
                                <img src="{{ asset($circle->profilePicture ?? 'img/logo2.jpg') }}" class="rounded-circle" width="40" height="40" alt="logo">
                                <div>
                                    <div class="fw-semibold">{{ $circle->circleName }}</div>
                                    <small class="text-muted">{{ $circle->city->cityName ?? 'N/A' }}</small>
                                </div>
                            </div>
                            <div class="text-end">
                                <div class="fw-semibold text-primary">₹ {{ number_format($circle->totalBusinessAmount ?? 0, 0) }}</div>
                                <small class="text-muted">👥 {{ $circle->members_count }}</small>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <!-- Right: Members List (col-md-9) -->
            <div id="memberCardsContainer" class="row g-4">
                {{-- Member cards will be loaded here --}}
            </div>

        </div>
    </div>


    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const circles = document.querySelectorAll('.circle-card');
            const container = document.getElementById('memberCardsContainer');

            circles.forEach(circle => {
                circle.addEventListener('click', function() {
                    const circleId = this.getAttribute('data-id');

                    fetch(`/get-circle-members/${circleId}`)
                        .then(response => response.text())
                        .then(html => {
                            container.innerHTML = html;
                        })
                        .catch(error => {
                            console.error('Error fetching members:', error);
                        });
                });
            });
        });
    </script>


    <style>
        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            /* spacing between cards */
        }

        .profile-card {
            width: 400px;
            /* slightly reduced to fit 3 in a row nicely */
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            background-color: #fff;
            margin: 20px;
            /* changed from centered to spaced for flexbox */
            transition: all 0.3s ease;
        }

        .profile-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
        }

        .header-image {
            width: 100%;
            height: 120px;
            object-fit: cover;
        }

        .profile-img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            border: 4px solid #fff;
            margin-top: -50px;
        }

        h5 {
            margin-top: 10px;
            margin-bottom: 4px;
            font-weight: 700;
            color: #1d3268;
        }

        .position {
            color: #1d3268;
            font-size: 14px;
            /* font-weight: bold; */
        }

        .info-section {
            display: flex;
            justify-content: space-around;
            margin-top: 15px;
            margin-bottom: 20px;
        }

        .icon-text {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            font-size: 13px;
            flex: 1;
        }

        .icon-text i {
            font-size: 22px;
            color: #e76a35;
            margin-bottom: 5px;
        }

        .company-category-section {
            display: flex;
            align-items: center;
            padding: 20px;
            border-top: 1px solid #f0f0f0;
            border-bottom: 1px solid #f0f0f0;
            gap: 20px;
        }

        .company-section,
        .category-section {
            flex: 1;
            min-width: 0;
            /* prevents overflow issues */
            text-align: center;
            word-wrap: break-word;
        }

        .company-section h2,
        .category-section h3 {
            white-space: normal;
            /* Allows text to wrap */
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            /* Limits to 2 lines */
            -webkit-box-orient: vertical;
            word-wrap: break-word;
            line-height: 1.4;
            /* Adjust for better readability */
            max-width: 100%;
        }

        .B-divider {
            width: 1px;
            background-color: #dcdcdc;
            height: 60px;
        }


        .logo-section {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 8px;
        }

        .logo-section img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid #e0e0e0;
        }

        .company-section h2,
        .category-section h3 {
            margin: 6px 0;
            color: #1d2951;
            font-size: 16px;
            font-weight: bold;
        }

        .category-section .label {
            color: gray;
            font-size: 12px;
            margin-bottom: 4px;
        }

        .keywords-container {
            text-align: center;
            margin: 15px 20px 10px;
        }

        .keyword-pill {
            display: inline-block;
            background-color: #f3f5fb;
            color: #3a3a3a;
            font-size: 12px;
            padding: 6px 12px;
            margin: 5px 5px;
            border-radius: 20px;
            border: 1px solid #e0e4f0;
            cursor: default;
        }

        .bottom-actions {
            display: flex;
            justify-content: space-between;
            /* Move buttons to corners */
            align-items: center;
            border-top: 1px solid #e6e6e6;
            padding: 10px 0;
            text-align: center;
            width: 100%;

        }

        .action-button {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 600;
            color: #1d2951;
            transition: color 0.2s;
            text-decoration: none;
            padding: 10px;
            gap: 8px;
            /* Space between icon and text */
        }

        .action-button.connected {
            color: #e76a35 !important;
            /* Orange color for connected users */
        }


        .action-button i {
            font-size: 16px;
            /* Adjust icon size if needed */
        }

        .divider {
            width: 1px;
            background-color: #e6e6e6;
            height: 100px;
        }


        .bottom-actions div:hover {
            color: #e76a35;
        }

        .bottom-divider {
            width: 1px;
            background-color: #e0e0e0;
            height: 25px;
        }

        /* Responsive adjustments */
        @media screen and (max-width: 1200px) {
            .profile-card {
                width: 280px;
            }
        }

        @media screen and (max-width: 1500px) {
            .profile-card {
                width: 280px;
            }
        }

        @media screen and (max-width: 992px) {
            .profile-card {
                width: 200px;
            }
        }

        @media screen and (max-width: 768px) {
            .profile-card {
                width: 220px;
            }

            .icon-text {
                font-size: 10px;
            }
        }

        @media screen and (max-width: 576px) {
            .profile-card {
                width: 100%;
            }
        }

        @media screen and (max-width: 320px) {
            .profile-card {
                width: 220px;
            }

            .icon-text {
                font-size: 9px;
            }
        }


        .initials {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: #c1c1c1;
            color: white;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            /* mix-blend-mode: color-burn; */

        }
    </style>
    <!-- Full CSS -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .circle-logo-sm {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 50%;
        }

        .member-card {
            background-color: #fff;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }

        .member-card-header {
            background-color: #f1f3f5;
            position: relative;
            height: 70px;
        }

        .profile-img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid #fff;
            background-color: #fff;
            position: absolute;
            top: -40px;
            left: 50%;
            transform: translateX(-50%);
            object-fit: cover;
        }

        .member-card-body {
            padding: 1.5rem 1rem 1rem;
        }

        .member-card-footer {
            padding: 0.75rem 1rem;
            border-top: 1px solid #e9ecef;
        }

        .tags span {
            background: #eef1f7;
            font-size: 12px;
            padding: 4px 10px;
            border-radius: 20px;
            margin: 2px;
            display: inline-block;
        }

        @media (max-width: 768px) {
            .profile-img {
                top: -30px;
                width: 60px;
                height: 60px;
            }
        }
    </style>
@endsection
