@forelse ($members as $member)
    <div class="col-12 col-sm-6 col-lg-4">
        <div class="profile-card shadow-sm rounded border-0">
            <img src="https://picsum.photos/600/120" class="header-image" alt="Header Image">
            <div class="text-center p-3">
                <img src="{{ asset('ProfilePhoto/' . ($member->profilePhoto ?? 'logo2.jpg')) }}" class="profile-img img-fluid rounded-circle mx-auto d-block" alt="Profile Image">
                <h5 class="member-name" style="color: #e76a35; font-weight: bold;">
                    {{ $member->firstName ?? 'N/A' }} {{ $member->lastName ?? 'N/A' }}
                </h5>
                <p class="position">{{ $member->users->roles ?? 'Position' }}</p>
                <div class="info-section">
                    @php
                        $isConnected = in_array($member->connection_status, ['Accepted', 'Connected']);
                    @endphp
                    <div class="icon-text" title="{{ $isConnected ? $member->user->email ?? 'N/A' : '****' }}">
                        <i class="bi bi-envelope-fill" style="color: #787c80;"></i>
                        <span>{{ $isConnected ? Str::limit($member->user->email ?? 'N/A', 15) : '****' }}</span>
                    </div>
                    <div class="icon-text" title="{{ $isConnected ? $member->user->contactNo ?? 'N/A' : '****' }}">
                        <i class="bi bi-telephone-fill" style="color: #787c80;"></i>
                        <span>{{ $isConnected ? Str::limit($member->user->contactNo ?? 'N/A', 10) : '****' }}</span>
                    </div>
                    <div class="icon-text">
                        <i class="bi bi-people-fill" style="color: #787c80;"></i>
                        <span>{{ $circle->circleName ?? 'N/A' }}</span>
                    </div>
                </div>
                <div class="company-category-section">
                    <div class="company-section">
                        <div class="logo-section">
                            @if (!empty($member->companyLogo))
                                <img src="{{ asset('CompanyLogo/' . $member->companyLogo) }}" class="company-logo" alt="Company Logo">
                            @endif
                            <div class="initials" style="{{ empty($member->companyLogo) ? 'display:flex;' : 'display:none;' }}">
                                {{ strtoupper(substr($member->companyName ?? 'C', 0, 1)) }}
                            </div>
                        </div>
                        <h2 title="{{ $member->companyName ?? 'Company Name' }}">
                            {{ $member->companyName ?? 'Company Name' }}
                        </h2>
                    </div>
                    <div class="divider"></div>
                    <div class="category-section">
                        <div class="label">Category</div>
                        <h3>{{ $member->bCategory->categoryName ?? 'N/A' }}</h3>
                    </div>
                </div>
                <div class="keywords-container row">
                    @php
                        $keyWords = json_decode($member->keyWords ?? '[]', true);
                    @endphp
                    @if (is_array($keyWords) && count($keyWords) > 0)
                        @foreach ($keyWords as $keyWord)
                            <span class="keyword-pill col">{{ $keyWord }}</span>
                        @endforeach
                    @endif
                </div>
            </div>
            <div class="bottom-actions">
                <div id="viewProfile" class="action-button left-action">
                    <a href="{{ route('foundPersonDetails', $member->id) }}">
                        <i class="bi bi-person-lines-fill" style="color: #1d3268;"></i><span style="color: #1d3268;">View Profile</span>
                    </a>
                </div>
                <div class="B-divider"></div>
                <div id="connectButton" class="action-button right-action btn w-100">
                    @if ($member->circleId == $authCircleId || $member->connection_status == 'Connected')
                        <button type="button" class="btn btn-connect fw-bold shadow-none" style="color: #e76a35;">
                            Connected &nbsp;<i class="bi bi-check-circle-fill" style="color: #e76a35;"></i>
                        </button>
                    @elseif ($member->connection_status == 'Not Connected')
                        <form action="{{ route('connect') }}" method="POST" class="d-inline-block">
                            @csrf
                            <input type="hidden" name="memberId" value="{{ $member->id }}">
                            <button type="submit" class="btn btn-connect shadow-none fw-bold" style="color: #1d3268;">
                                Connect &nbsp;<i class="bi bi-person-plus-fill fw-bold" style="color: #1d3268;"></i>
                            </button>
                        </form>
                    @elseif ($member->connection_status == 'Accepted')
                        <button id="messageButton" class="btn btn-connect ms-2">Message</button>
                    @elseif ($member->connection_status == 'Pending')
                        <button type="button" class="btn btn-connect fw-bold shadow-none" style="color: #e76a35;">
                            Requested &nbsp;<i class="bi bi-clock" style="color: #e76a35;"></i>
                        </button>
                    @elseif ($member->connection_status == 'Rejected')
                        <form action="{{ route('connect') }}" method="POST" class="d-inline-block">
                            @csrf
                            <input type="hidden" name="memberId" value="{{ $member->id }}">
                            <button type="submit" class="btn btn-connect shadow-none fw-bold" style="color: #1d3268;">
                                Connect &nbsp;<i class="bi bi-person-plus-fill fw-bold" style="color: #1d3268;"></i>
                            </button>
                        </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
@empty
    <p class="text-center">No active members found in {{ $circleName }} circle.</p>
@endforelse
