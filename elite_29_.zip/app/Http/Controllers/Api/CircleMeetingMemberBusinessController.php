<?php

namespace App\Http\Controllers\Api;

use App\Utils\Utils;
use App\Models\Circle;
use App\Models\Member;
use App\Models\CircleMeetingMembersBusiness;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class CircleMemberBusinessController extends Controller
{
    public function index(Request $request)
    {
        try {
            $userId = Auth::id();

            $member = Member::where('userId', $userId)->first();

            if (!$member) {
                return Utils::errorResponse(['error' => 'Member not found for the authenticated user'], 'Not Found', 404);
            }

            $circleMembersBusiness = CircleMeetingMembersBusiness::where('memberId', $member->id)
                ->where('status', 'Active')
                ->orderBy('id', 'DESC')
                ->get();

            return Utils::sendResponse(['circleMembersBusiness' => $circleMembersBusiness], 'Circle Meeting Members Business retrieved successfully', 200);
        } catch (\Throwable $th) {
            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }

    public function view(Request $request, $id)
    {
        try {
            $circleMemberBusiness = CircleMeetingMembersBusiness::findOrFail($id);
            return Utils::sendResponse(['circleMemberBusiness' => $circleMemberBusiness], 'Circle Meeting Member Business retrieved successfully', 200);
        } catch (\Throwable $th) {
            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'businessGiver' => 'required',
            'amount' => 'required',
            'date' => 'required',
        ]);

        if ($validator->fails()) {
            return Utils::errorResponse(['error' => $validator->errors()->first()], 'Invalid Input', 400);
        }

        try {
            $memberId = Auth::id();
            $member = Member::where('userId', $memberId)->first();

            if (!$member) {
                return Utils::errorResponse(['error' => 'Member not found for the authenticated user'], 'Not Found', 404);
            }

            $circleMemberBusiness = new CircleMeetingMembersBusiness();
            $circleMemberBusiness->memberId = $member->id;
            $circleMemberBusiness->businessGiver = $request->input('businessGiver');
            $circleMemberBusiness->amount = $request->input('amount');
            $circleMemberBusiness->date = $request->input('date');
            $circleMemberBusiness->status = 'Active';
            $circleMemberBusiness->save();

            return Utils::sendResponse(['circleMemberBusiness' => $circleMemberBusiness], 'Circle Meeting Member Business Created Successfully!', 201);
        } catch (\Throwable $th) {
            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'businessGiver' => 'required',
            'amount' => 'required',
            'date' => 'required',
        ]);

        if ($validator->fails()) {
            return Utils::errorResponse(['error' => $validator->errors()->first()], 'Invalid Input', 400);
        }

        try {
            $memberId = Auth::id();
            $member = Member::where('userId', $memberId)->first();

            if (!$member) {
                return Utils::errorResponse(['error' => 'Member not found for the authenticated user'], 'Not Found', 404);
            }

            $circleMemberBusiness = CircleMeetingMembersBusiness::find($id);

            if (!$circleMemberBusiness) {
                return Utils::errorResponse(['error' => 'Circle Meeting Member Business not found'], 'Not Found', 404);
            }

            if ($circleMemberBusiness->memberId != $member->id) {
                return Utils::errorResponse(['error' => 'Unauthorized'], 'Unauthorized', 403);
            }

            $circleMemberBusiness->businessGiver = $request->input('businessGiver');
            $circleMemberBusiness->amount = $request->input('amount');
            $circleMemberBusiness->date = $request->input('date');
            $circleMemberBusiness->save();

            return Utils::sendResponse(['circleMemberBusiness' => $circleMemberBusiness], 'Circle Meeting Member Business Updated Successfully!', 200);
        } catch (\Throwable $th) {
            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }

    public function delete(Request $request, $id)
    {
        try {
            $memberId = Auth::id();
            $member = Member::where('userId', $memberId)->first();

            if (!$member) {
                return Utils::errorResponse(['error' => 'Member not found for the authenticated user'], 'Not Found', 404);
            }

            $circleMemberBusiness = CircleMeetingMembersBusiness::find($id);

            if (!$circleMemberBusiness) {
                return Utils::errorResponse(['error' => 'Circle Meeting Member Business not found'], 'Not Found', 404);
            }

            if ($circleMemberBusiness->memberId != $member->id) {
                return Utils::errorResponse(['error' => 'Unauthorized'], 'Unauthorized', 403);
            }

            $circleMemberBusiness->status = "Deleted";
            $circleMemberBusiness->save();

            return Utils::sendResponse([], 'Circle Meeting Member Business Deleted Successfully!', 200);
        } catch (\Throwable $th) {
            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }
}
