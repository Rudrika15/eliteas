<style>
    /* Leaderboard style  */
    .profile-card {
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        text-align: center;
        padding: 20px;
        border-top: 4px solid #e76a35;
        margin-bottom: 20px;
    }

    .profile-img {
        width: 90px;
        height: 90px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid #1d3268;
    }

    .profile-title {
        font-size: 14px;
        font-weight: bold;
        color: #e76a35;
        margin-top: 10px;
    }

    .profile-name {
        font-size: 16px;
        font-weight: bold;
        color: #1d3268;
        margin-bottom: 5px;
    }

    .profile-info {
        font-size: 14px;
        color: #1d3268;
        margin: 5px 0;
    }

    .profile-buttons {
        margin-top: 15px;
    }

    .profile-buttons a {
        display: inline-block;
        text-decoration: none;
        padding: 8px 12px;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        margin: 5px;
    }

    .btn-view {
        background-color: #1d3268;
        color: white;
    }

    .btn-connect {
        /* background-color: #e76a35; */
        /* color: white; */
    }

    /* Stats Cards Styling */
    /* .stat-card {
        background: linear-gradient(to right, #f8f9fa, #e8eaf6);
        border-radius: 12px;
        padding: 10px;
        max-height: 200px;
        display: flex;
    }

    .stat-icon {
        font-size: 60px;
        color: rgba(108, 117, 125, 0.6);
    } */

    .stat-card {
        background: linear-gradient(to right, #f8f9fa, #e8eaf6);
        border-radius: 12px;
        padding: 10px;
        position: relative;
        /* Enables absolute positioning for the icon */
        overflow: hidden;
        /* Ensures content does not overflow */
    }

    .stat-icon {
        font-size: 60px;
        color: rgba(108, 117, 125, 0.6);
        position: absolute;
        bottom: 10px;
        /* Positions icon at the bottom */
        right: 10px;
        /* Positions icon at the right */
    }




    .text-gradient {
        color: #ab2626;
        font-size: 20px;
    }

    .content {
        margin-right: auto;
    }

    /* Responsive Grid Layout for Leaderboard */
    @media (max-width: 767px) {
        .profile-card {
            margin-bottom: 15px;
        }

        .stat-card {
            margin-bottom: 15px;
        }
    }

    .card-text {
        font-size: 14px;
    }

    .bottom-card {
        height: auto;
        align-self: center;
        margin-bottom: 10px;
    }
</style>

<style>
    body {
        background-color: #f8f9fa;
    }

    .section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }

    .section-header a {
        text-decoration: none;
        color: #000;
        font-weight: 500;
    }

    .event-card {
        border: none;
        border-radius: 10px;
        overflow: hidden;
        background: #fff;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        transition: 0.3s;
    }

    .event-card:hover {
        transform: scale(1.02);
    }

    .event-img {
        height: 180px;
        object-fit: cover;
        width: 100%;
        border-radius: 10px 10px 0 0;
    }

    .event-details {
        padding: 15px;
    }

    .event-meta {
        font-size: 14px;
        color: #6c757d;
        display: flex;
        align-items: center;
    }

    .event-meta i {
        margin-right: 5px;
    }

    .badge-price {
        background-color: #f8d7da;
        color: #dc3545;
        font-weight: bold;
        padding: 5px 10px;
        border-radius: 15px;
        font-size: 14px;
    }


    .event-card-upcoming {
        background-color: #fafafd;
    }
</style>




{{-- <style>
    .leaderboard .card-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 30px;
        /* spacing between cards */
    }

    .leaderboard .profile-card {
        width: 220px;
        height: 486px;
        /* slightly reduced to fit 3 in a row nicely */
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
        background-color: #fff;
        margin: 20px;
        /* changed from centered to spaced for flexbox */
        transition: all 0.3s ease;
    }

    .leaderboard .profile-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
    }

    .leaderboard .header-image {
        width: 100%;
        height: 60px;
        object-fit: cover;
    }

    .leaderboard .profile-img {
        /* width: 150px;
        height: 150px; */
        object-fit: cover;
        border-radius: 50%;
        border: 4px solid #fff;
        margin-top: -50px;
    }

    .leaderboard h5 {
        margin-top: 10px;
        margin-bottom: 4px;
        font-weight: 700;
        color: #1d3268;
    }

    .leaderboard .position {
        color: #1d3268;
        font-size: 14px;
        /* font-weight: bold; */
    }

    .leaderboard .info-section {
        display: flex;
        justify-content: space-around;
        margin-top: 15px;
        margin-bottom: 20px;
    }

    .leaderboard .icon-text {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        font-size: 13px;
        flex: 1;
    }

    .leaderboard .icon-text i {
        font-size: 22px;
        color: #e76a35;
        margin-bottom: 5px;
    }

    .leaderboard .company-category-section {
        display: flex;
        align-items: center;
        padding: 20px;
        border-top: 1px solid #f0f0f0;
        border-bottom: 1px solid #f0f0f0;
        gap: 20px;
    }

    .leaderboard .company-section,
    .leaderboard .category-section {
        flex: 1;
        min-width: 0;
        /* prevents overflow issues */
        text-align: center;
        word-wrap: break-word;
    }

    .leaderboard .company-section h2,
    .leaderboard .category-section h3 {
        white-space: normal;
        /* Allows text to wrap */
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        /* Limits to 2 lines */
        -webkit-box-orient: vertical;
        word-wrap: break-word;
        line-height: 1.4;
        /* Adjust for better readability */
        max-width: 100%;
    }

    .leaderboard .B-divider {
        width: 1px;
        background-color: #dcdcdc;
        height: 60px;
    }


    .leaderboard .logo-section {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 8px;
    }

    .leaderboard .logo-section img {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
        border: 1px solid #e0e0e0;
    }

    .leaderboard .company-section h2,
    .leaderboard .category-section h3 {
        margin: 6px 0;
        color: #1d2951;
        font-size: 16px;
        font-weight: bold;
    }

    .leaderboard .category-section .label {
        color: gray;
        font-size: 12px;
        margin-bottom: 4px;
    }

    .leaderboard .keywords-container {
        text-align: center;
        margin: 15px 20px 10px;
    }

    .leaderboard .keyword-pill {
        display: inline-block;
        background-color: #f3f5fb;
        color: #3a3a3a;
        font-size: 12px;
        padding: 6px 12px;
        margin: 5px 5px;
        border-radius: 20px;
        border: 1px solid #e0e4f0;
        cursor: default;
    }

    .leaderboard .bottom-actions {
        display: flex;
        justify-content: space-between;
        /* Move buttons to corners */
        align-items: center;
        border-top: 1px solid #e6e6e6;
        padding: 10px 0;
        text-align: center;
        width: 100%;

    }

    .leaderboard .action-button {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: 600;
        color: #1d2951;
        transition: color 0.2s;
        text-decoration: none;
        padding: 10px;
        gap: 8px;
        /* Space between icon and text */
    }

    .leaderboard .action-button.connected {
        color: #e76a35 !important;
        /* Orange color for connected users */
    }


    .leaderboard .action-button i {
        font-size: 16px;
        /* Adjust icon size if needed */
    }

    .leaderboard .divider {
        width: 1px;
        background-color: #e6e6e6;
        height: 100px;
    }


    .leaderboard .bottom-actions div:hover {
        color: #e76a35;
    }

    .leaderboard .bottom-divider {
        width: 1px;
        background-color: #e0e0e0;
        height: 25px;
    }

    /* Responsive adjustments */
    @media screen and (max-width: 1200px) {
        .leaderboard .profile-card {
            width: 280px;
        }
    }

    @media screen and (max-width: 1500px) {
        .leaderboard .profile-card {
            width: 200px;
        }
    }

    @media screen and (max-width: 992px) {
        .leaderboard .profile-card {
            width: 200px;
        }
    }

    @media screen and (max-width: 768px) {
        .leaderboard .profile-card {
            width: 220px;
        }

        .leaderboard .icon-text {
            font-size: 10px;
        }
    }

    @media screen and (max-width: 576px) {
        .leaderboard .profile-card {
            width: 100%;
        }
    }

    @media screen and (max-width: 320px) {
        .leaderboard .profile-card {
            width: 220px;
        }

        .leaderboard .icon-text {
            font-size: 9px;
        }
    }


    .leaderboard .initials {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background-color: #c1c1c1;
        color: white;
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        /* mix-blend-mode: color-burn; */

    }
</style> --}}


<style>
    .leaderboard .card-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 30px;
        /* spacing between cards */
    }

    .leaderboard .profile-card {
        width: 400px;
        /* slightly reduced to fit 3 in a row nicely */
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
        background-color: #fff;
        margin: 20px;
        /* changed from centered to spaced for flexbox */
        transition: all 0.3s ease;
    }

    .leaderboard .profile-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
    }

    .leaderboard .header-image {
        width: 100%;
        height: 120px;
        object-fit: cover;
    }

    .leaderboard .profile-img {
        width: 150px;
        height: 150px;
        object-fit: cover;
        border-radius: 50%;
        border: 4px solid #fff;
        margin-top: -50px;
    }

    .leaderboard h5 {
        margin-top: 10px;
        margin-bottom: 4px;
        font-weight: 700;
        color: #1d3268;
    }

    .leaderboard .position {
        color: #1d3268;
        font-size: 14px;
        /* font-weight: bold; */
    }

    .leaderboard .info-section {
        display: flex;
        justify-content: space-around;
        margin-top: 15px;
        margin-bottom: 20px;
    }

    .leaderboard .icon-text {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        font-size: 13px;
        flex: 1;
    }

    .leaderboard .icon-text i {
        font-size: 22px;
        color: #e76a35;
        margin-bottom: 5px;
    }

    .leaderboard .company-category-section {
        display: flex;
        align-items: center;
        padding: 20px;
        border-top: 1px solid #f0f0f0;
        border-bottom: 1px solid #f0f0f0;
        gap: 20px;
    }

    .leaderboard .company-section,
    .leaderboard .category-section {
        flex: 1;
        min-width: 0;
        /* prevents overflow issues */
        text-align: center;
        word-wrap: break-word;
    }

    .leaderboard .company-section h2,
    .leaderboard .category-section h3 {
        white-space: normal;
        /* Allows text to wrap */
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        /* Limits to 2 lines */
        -webkit-box-orient: vertical;
        word-wrap: break-word;
        line-height: 1.4;
        /* Adjust for better readability */
        max-width: 100%;
    }

    .leaderboard .B-divider {
        width: 1px;
        background-color: #dcdcdc;
        height: 60px;
    }


    .leaderboard .logo-section {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 8px;
    }

    .leaderboard .logo-section img {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
        border: 1px solid #e0e0e0;
    }

    .leaderboard .company-section h2,
    .leaderboard .category-section h3 {
        margin: 6px 0;
        color: #1d2951;
        font-size: 16px;
        font-weight: bold;
    }

    .leaderboard .category-section .label {
        color: gray;
        font-size: 12px;
        margin-bottom: 4px;
    }

    .leaderboard .keywords-container {
        text-align: center;
        /* margin: 15px 20px 10px; */
    }

    .leaderboard .keyword-pill {
        display: inline-block;
        background-color: #f3f5fb;
        color: #3a3a3a;
        font-size: 12px;
        padding: 6px 12px;
        margin: 5px 5px;
        border-radius: 20px;
        border: 1px solid #e0e4f0;
        cursor: default;
    }

    .leaderboard .bottom-actions {
        display: flex;
        justify-content: space-between;
        /* Move buttons to corners */
        align-items: center;
        border-top: 1px solid #e6e6e6;
        padding: 10px 0;
        text-align: center;
        width: 100%;

    }

    .leaderboard .action-button {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: 600;
        color: #1d2951;
        transition: color 0.2s;
        text-decoration: none;
        padding: 10px;
        gap: 8px;
        /* Space between icon and text */
    }

    .leaderboard .action-button.connected {
        color: #e76a35 !important;
        /* Orange color for connected users */
    }


    .leaderboard .action-button i {
        font-size: 16px;
        /* Adjust icon size if needed */
    }

    .leaderboard .divider {
        width: 1px;
        background-color: #e6e6e6;
        height: 100px;
    }


    .leaderboard .bottom-actions div:hover {
        color: #e76a35;
    }

    .leaderboard .bottom-divider {
        width: 1px;
        background-color: #e0e0e0;
        height: 25px;
    }

    /* Responsive adjustments */

    @media screen and (max-width: 2560px) {
        .leaderboard .profile-card {
            width: 230px !important;
        }

        .leaderboard .info-section .icon-text {
            font-size: 8px;
        }

        .leaderboard .company-category-section {
            padding: 0%;
            gap: 0%;
        }

        .leaderboard .company-section,
        .leaderboard .category-section {
            flex: 1;
            min-width: 0;
            /* prevents overflow issues */
            text-align: center;
            word-wrap: break-word;
        }

        .leaderboard .company-section h2,
        .leaderboard .category-section h3 {
            margin: 0px 0;
            color: #1d2951;
            font-size: 10px;
            font-weight: bold;
        }

        .leaderboard .profile-img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid #e0e0e0;
        }

        .leaderboard .header-image {
            width: 100%;
            height: 60px;
            object-fit: cover;
        }

        .leaderboard .bottom-actions {
            font-size: 12px;
        }

        .leaderboard .btn-connect {
            font-size: 12px;
            color: #1d3268;
        }

        .leaderboard .position {
            font-size: 8px;
        }

        .leaderboard .member-name {
            font-size: 12px;
        }
    }


    @media screen and (max-width: 1440px) {
        .leaderboard .profile-card {
            width: 195px !important;
        }

        .leaderboard .info-section .icon-text {
            font-size: 12px;
        }

        .leaderboard .company-category-section {
            padding: 0%;
            gap: 0%;
        }

        .leaderboard .company-section,
        .leaderboard .category-section {
            flex: 1;
            min-width: 0;
            /* prevents overflow issues */
            text-align: center;
            word-wrap: break-word;
        }

        .leaderboard .company-section h2,
        .leaderboard .category-section h3 {
            margin: 0px 0;
            color: #1d2951;
            font-size: 12px;
            font-weight: bold;
        }

        .leaderboard .profile-img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid #e0e0e0;
        }

        .leaderboard .header-image {
            width: 100%;
            height: 60px;
            object-fit: cover;
        }

        .leaderboard .bottom-actions {
            font-size: 12px;
        }

        .leaderboard .btn-connect {
            font-size: 12px;
        }

        .leaderboard .position {
            font-size: 12px;
        }

        .leaderboard .member-name {
            font-size: 15px;
        }


    }

    @media screen and (max-width: 1024px) {
        .leaderboard .profile-card {
            width: 195px !important;
        }

        .leaderboard .info-section .icon-text {
            font-size: 12px;
        }

        .leaderboard .company-category-section {
            padding: 0%;
            gap: 0%;
        }

        .leaderboard .company-section,
        .leaderboard .category-section {
            flex: 1;
            min-width: 0;
            /* prevents overflow issues */
            text-align: center;
            word-wrap: break-word;
        }

        .leaderboard .company-section h2,
        .leaderboard .category-section h3 {
            margin: 0px 0;
            color: #1d2951;
            font-size: 12px;
            font-weight: bold;
        }

        .leaderboard .profile-img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid #e0e0e0;
        }

        .leaderboard .header-image {
            width: 100%;
            height: 60px;
            object-fit: cover;
        }

        .leaderboard .bottom-actions {
            font-size: 12px;
        }

        .leaderboard .btn-connect {
            font-size: 12px;
        }

        .leaderboard .position {
            font-size: 12px;
        }

        .leaderboard .member-name {
            font-size: 15px;
        }


    }

    @media screen and (max-width: 992px) {
        .leaderboard .profile-card {
            width: 210px;
        }


    }

    @media screen and (max-width: 1500px) {
        .leaderboard .profile-card {
            width: 200px;
        }


    }

    @media screen and (max-width: 768px) {
        .leaderboard .profile-card {
            width: 220px;
        }

        .leaderboard .icon-text {
            font-size: 10px;
        }
    }

    @media screen and (max-width: 576px) {
        .leaderboard .profile-card {
            width: 100%;
        }
    }

    @media screen and (max-width: 320px) {
        .leaderboard .profile-card {
            width: 220px;
        }

        .leaderboard .icon-text {
            font-size: 9px;
        }
    }


    .leaderboard .initials {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background-color: #c1c1c1;
        color: white;
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        /* mix-blend-mode: color-burn; */

    }

    .leaderboard .heading {
        color: #1d3268;
        font-weight: bold;
        font-size: 14px;
        margin-bottom: 10px;
    }

    .leaderboard .col-lg-4 {
        width: 31.33333333% !important;
    }
</style>


{{-- upcoming events css start --}}

{{-- <style>
    .upcoming-events {
        max-width: 1100px;
        margin: auto;
        background: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    }

    /* Horizontal Scroll */
    .upcoming-events .events-container {
        display: flex;
        gap: 16px;
        overflow-x: auto;
        scroll-behavior: smooth;
        padding-bottom: 10px;
    }

    .upcoming-events .events-container::-webkit-scrollbar {
        display: none;
        /* Hide scrollbar */
    }

    .upcoming-events .event-card {
        min-width: 300px;
        max-width: 320px;
        border-radius: 10px;
        overflow: hidden;
        position: relative;
        background: #fff;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    }

    .upcoming-events .event-card img {
        width: 100%;
        height: 180px;
        object-fit: cover;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }

    .upcoming-events .event-info {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        background: linear-gradient(to top, rgba(0, 0, 0, 0.7), transparent);
        padding: 10px;
        color: white;
    }

    .upcoming-events .event-details {
        padding: 12px;
    }

    .upcoming-events .price-tag {
        background: #ffe0e0;
        color: #d9534f;
        padding: 5px 10px;
        border-radius: 5px;
        font-weight: 600;
    }
</style> --}}

<style>
    .upcoming-events {
        max-width: 1100px;
        margin: auto;
        background: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    }

    /* Horizontal Scroll */
    .upcoming-events .events-container {
        display: flex;
        gap: 16px;
        overflow-x: auto;
        scroll-behavior: smooth;
        padding-bottom: 10px;
    }

    .upcoming-events .events-container::-webkit-scrollbar {
        display: none;
        /* Hide scrollbar */
    }

    .upcoming-events .event-card {
        min-width: 300px;
        max-width: 320px;
        border-radius: 10px;
        overflow: hidden;
        position: relative;
        background: #fff;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    }

    .upcoming-events .event-card img {
        width: 100%;
        height: 180px;
        object-fit: cover;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }

    /* Overlay for Text */
    .upcoming-events .event-info {
        position: relative;
        bottom: 0;
        left: 0;
        width: 100%;
        /* background: linear-gradient(to top, rgba(0, 0, 0, 0.8), transparent); */
        padding: 10px;
        color: #1d3268;
    }

    .upcoming-events .event-info h6 {
        margin-bottom: 5px;
        font-size: 15px;
        font-weight: 600;
    }

    .upcoming-events .event-info small {
        font-size: 12px;
        display: block;
        opacity: 0.9;
    }

    /* Event Details Below */
    .upcoming-events .event-details {
        padding: 12px;
    }

    .upcoming-events .price-tag {
        background: #ffe0e0;
        color: #d9534f;
        padding: 5px 10px;
        border-radius: 30px;
        font-weight: 600;
    }

    .card-title {
        padding: 0% !important;
    }
</style>


{{-- php code for get city count start --}}

@php
    use App\Models\Member;
    use App\Models\Circle;
    use Illuminate\Support\Facades\DB;

    // Get distinct city IDs from active members
    $memberCities = Member::where('status', 'Active')->whereNotNull('cityId')->distinct()->pluck('cityId')->toArray();

    // Get distinct city IDs from circles
    $circleCities = Circle::whereNotNull('cityId')->distinct()->pluck('cityId')->toArray();

    // Combine both lists and remove duplicates
    $allCities = array_unique(array_merge($memberCities, $circleCities));

    // Final total unique count
    $cityCount = count($allCities);
    // dd($allCities);
@endphp

{{-- php code for get city count end --}}

@role('Digital Member')
    @php
        $totalBusinessAmount = \App\Models\CircleMeetingMembersBusiness::where('status', 'Active')->sum('amount');
        $totalReferences = \App\Models\CircleMeetingMembersReference::where('status', 'Active')->count();
        $totalIbms = \App\Models\CircleCall::where('status', 'Active')->count();
    @endphp

    <style>
        .compact-stats .stat-card {
            padding: 8px;
            border-radius: 10px;
        }

        .compact-stats .stat-value {
            font-size: 1.25rem;
            font-weight: 700;
            color: #ab2626;
            line-height: 1.2;
        }

        .compact-stats .stat-label {
            font-size: 0.75rem;
            color: #6c757d;
            text-transform: uppercase;
            font-weight: 600;
            margin-top: 2px;
        }

        .compact-stats .stat-icon {
            position: static !important;
            font-size: 1.75rem;
            color: rgba(108, 117, 125, 0.6);
        }
    </style>
    <div class="row mb-3 compact-stats">
        <div class="col-md-4 col-12 mb-2">
            <div class="card shadow-sm border-0 stat-card">
                <div class="d-flex align-items-center justify-content-between p-2">
                    <div>
                        <div class="stat-value">₹ {{ number_format($totalBusinessAmount ?? 0, 0) }}</div>
                        <div class="stat-label">Total Business</div>
                    </div>
                    <i class="bi bi-cash-stack stat-icon"></i>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12 mb-2">
            <div class="card shadow-sm border-0 stat-card">
                <div class="d-flex align-items-center justify-content-between p-2">
                    <div>
                        <div class="stat-value">{{ $totalReferences }}</div>
                        <div class="stat-label">Total Referrals</div>
                    </div>
                    <i class="bi bi-person-rolodex stat-icon"></i>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12 mb-2">
            <div class="card shadow-sm border-0 stat-card">
                <div class="d-flex align-items-center justify-content-between p-2">
                    <div>
                        <div class="stat-value">{{ $totalIbms }}</div>
                        <div class="stat-label">Total IBMs</div>
                    </div>
                    <i class="bi bi-calendar-event stat-icon"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Cities Card -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0 p-2 stat-card position-relative overflow-hidden">
                <div class="row">
                    <div class="col-md-6">
                        <div class="content p-3">
                            <h2 class="fw-bold text-gradient">{{ $cityCount }}</h2>
                            <p class="text-uppercase text-muted fw-semibold">Cities</p>
                        </div>
                    </div>
                </div>
                <!-- Icon positioned at the bottom right, overlapping slightly -->
                <i class="bi bi-buildings stat-icon position-absolute" style="bottom: -30px; right: -10px; font-size: 5rem; opacity: 0.6;"></i>
            </div>
        </div>

        <!-- Circles Card -->
        {{-- <div class="col-md-4">
        <div class="card shadow-sm border-0 p-2 stat-card position-relative overflow-hidden">
            <div class="row">
                <div class="col-md-6">
                    <div class="content p-3">
                        <h2 class="fw-bold text-gradient">{{ $circleCount }}</h2>
                        <p class="text-uppercase text-muted fw-semibold">Circles</p>
                    </div>
                </div>
            </div>
            <i class="bi bi-bullseye stat-icon" style="bottom: -30px; right: -10px; font-size: 5rem; opacity: 0.6;"></i>
        </div>
    </div> --}}

        <!-- Members Card -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0 p-2 stat-card position-relative overflow-hidden">
                <div class="row">
                    <div class="col-md-7">
                        <div class="content p-3">
                            <h2 class="fw-bold text-gradient">{{ $membersCount }}</h2>
                            <p class="text-uppercase text-muted fw-semibold">Members Across UBN</p>
                        </div>
                    </div>
                </div>
                <i class="bi bi-people stat-icon" style="bottom: -30px; right: -10px; font-size: 5rem; opacity: 0.6;"></i>
            </div>
        </div>
    </div>
@endrole

{{-- upcoming events css end --}}

@role('Member')

    @php
        $totalBusinessAmount = \App\Models\CircleMeetingMembersBusiness::where('status', 'Active')->sum('amount');
        $totalReferences = \App\Models\CircleMeetingMembersReference::where('status', 'Active')->count();
        $totalIbms = \App\Models\CircleCall::where('status', 'Active')->count();
    @endphp

    <div class="container mt-4">
        <div class="row">
            <!-- Left Section (7 Columns) -->
            <div class="col-lg-8 col-md-12">
                <style>
                    .compact-stats .stat-card {
                        padding: 8px;
                        border-radius: 10px;
                    }

                    .compact-stats .stat-value {
                        font-size: 1.25rem;
                        font-weight: 700;
                        color: #ab2626;
                        line-height: 1.2;
                    }

                    .compact-stats .stat-label {
                        font-size: 0.75rem;
                        color: #6c757d;
                        text-transform: uppercase;
                        font-weight: 600;
                        margin-top: 2px;
                    }

                    .compact-stats .stat-icon {
                        position: static !important;
                        font-size: 1.75rem;
                        color: rgba(108, 117, 125, 0.6);
                    }
                </style>
                <div class="row mb-3 compact-stats">
                    <div class="col-md-4 col-12 mb-2">
                        <div class="card shadow-sm border-0 stat-card">
                            <div class="d-flex align-items-center justify-content-between p-2">
                                <div>
                                    <div class="stat-value">₹ {{ number_format($totalBusinessAmount ?? 0, 0) }}</div>
                                    <div class="stat-label">Total Business</div>
                                </div>
                                <i class="bi bi-cash-stack stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-12 mb-2">
                        <div class="card shadow-sm border-0 stat-card">
                            <div class="d-flex align-items-center justify-content-between p-2">
                                <div>
                                    <div class="stat-value">{{ $totalReferences }}</div>
                                    <div class="stat-label">Total Referrals</div>
                                </div>
                                <i class="bi bi-person-rolodex stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-12 mb-2">
                        <div class="card shadow-sm border-0 stat-card">
                            <div class="d-flex align-items-center justify-content-between p-2">
                                <div>
                                    <div class="stat-value">{{ $totalIbms }}</div>
                                    <div class="stat-label">Total IBMs</div>
                                </div>
                                <i class="bi bi-calendar-event stat-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- Cities Card -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0 p-2 stat-card position-relative overflow-hidden">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="content p-3">
                                        <h2 class="fw-bold text-gradient">{{ $cityCount }}</h2>
                                        <p class="text-uppercase text-muted fw-semibold">Cities</p>
                                    </div>
                                </div>
                            </div>
                            <!-- Icon positioned at the bottom right, overlapping slightly -->
                            <i class="bi bi-buildings stat-icon position-absolute" style="bottom: -30px; right: -10px; font-size: 5rem; opacity: 0.6;"></i>
                        </div>
                    </div>

                    <!-- Circles Card -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0 p-2 stat-card position-relative overflow-hidden">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="content p-3">
                                        <h2 class="fw-bold text-gradient">{{ $circleCount }}</h2>
                                        <p class="text-uppercase text-muted fw-semibold">Circles</p>
                                    </div>
                                </div>
                            </div>
                            <i class="bi bi-bullseye stat-icon" style="bottom: -30px; right: -10px; font-size: 5rem; opacity: 0.6;"></i>
                        </div>
                    </div>

                    <!-- Members Card -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0 p-2 stat-card position-relative overflow-hidden">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="content p-3">
                                        <h2 class="fw-bold text-gradient">{{ $membersCount }}</h2>
                                        <p class="text-uppercase text-muted fw-semibold">Members</p>
                                    </div>
                                </div>
                            </div>
                            <i class="bi bi-people stat-icon" style="bottom: -30px; right: -10px; font-size: 5rem; opacity: 0.6;"></i>
                        </div>
                    </div>
                </div>



                <h1 class="text-center card-title" id="leaderboard-title"></h1>

                <script>
                    const date = new Date();
                    const lastMonth = new Date(date.getFullYear(), date.getMonth() - 1, 1);
                    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                    document.getElementById("leaderboard-title").innerHTML = `Leaderboard - ${months[lastMonth.getMonth()]} ${date.getFullYear()}`;
                </script>

                <style>
                    .fb-card {
                        background-color: #ffffff;
                        border-radius: 10px;
                        overflow: hidden;
                        border: 1px solid #e0e0e0;
                        height: 100%;
                        display: flex;
                        flex-direction: column;
                        font-family: sans-serif;
                        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
                    }

                    .fb-card-img-wrapper {
                        width: 100%;
                        padding-top: 100%;
                        /* 1:1 Aspect Ratio */
                        position: relative;
                        background-color: #f8f9fa;
                        border-bottom: 1px solid #e0e0e0;
                    }

                    .fb-card-img {
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        object-fit: cover;
                    }

                    .fb-card-body {
                        padding: 16px;
                        flex-grow: 1;
                        display: flex;
                        flex-direction: column;
                        background-color: #ffffff;
                    }

                    .fb-card-title {
                        color: #1d3268;
                        font-size: 20px;
                        font-weight: 700;
                        margin-bottom: 4px;
                        line-height: 1.2;
                    }

                    .fb-card-subtitle {
                        color: #65676b;
                        font-size: 15px;
                        margin-bottom: 16px;
                        display: flex;
                        align-items: center;
                        gap: 6px;
                        flex-wrap: wrap;
                    }

                    .fb-card-info {
                        color: #65676b;
                        font-size: 14px;
                        margin-bottom: 16px;
                        line-height: 1.5;
                    }

                    .fb-card-info i {
                        color: #e76a35;
                    }

                    .fb-badge {
                        position: absolute;
                        top: 10px;
                        left: 10px;
                        background: #e76a35;
                        color: #fff;
                        padding: 4px 10px;
                        border-radius: 4px;
                        font-size: 12px;
                        font-weight: 600;
                        z-index: 10;
                        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
                    }

                    .fb-btn {
                        width: 100%;
                        border: none;
                        border-radius: 6px;
                        padding: 8px 0;
                        font-weight: 600;
                        font-size: 15px;
                        cursor: pointer;
                        transition: background 0.2s;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        text-decoration: none;
                    }

                    .fb-btn:hover {
                        text-decoration: none;
                    }

                    .fb-btn-primary {
                        background-color: #1d3268;
                        color: #fff;
                    }

                    .fb-btn-primary:hover {
                        background-color: #15244d;
                        color: #fff;
                    }

                    .fb-btn-secondary {
                        background-color: #e4e6eb;
                        color: #1d3268;
                        margin-top: 10px;
                    }

                    .fb-btn-secondary:hover {
                        background-color: #d8dadf;
                        color: #1d3268;
                    }

                    .fb-btn-disabled {
                        background-color: #e4e6eb;
                        color: #bcc0c4;
                        cursor: default;
                    }
                </style>

                <div class="leaderboard mt-3">
                    <div class="row g-4">
                        {{-- Card 1: Top IBM Member --}}
                        @if ($circlecalls)
                            <div class="col-sm-6 col-lg-4">
                                <div class="fb-card shadow-sm">
                                    <div class="fb-card-img-wrapper">
                                        <span class="fb-badge">Top IBM Member</span>
                                        <img src="{{ asset('ProfilePhoto/' . ($circlecalls['member']->profilePhoto ?? 'profile.png')) }}" class="fb-card-img" alt="Profile Image">
                                    </div>
                                    <div class="fb-card-body">
                                        <h5 class="fb-card-title">{{ $circlecalls['member']->firstName }} {{ $circlecalls['member']->lastName }}</h5>

                                        <div class="fb-card-subtitle">
                                            <i class="bi bi-people-fill"></i>
                                            {{ $circlecalls['member']->circle->circleName }}
                                            <span>&bull;</span>
                                            <span>{{ $circlecalls['count'] }} IBMs</span>
                                        </div>

                                        <div class="fb-card-info">
                                            @if (!empty($circlecalls['member']->companyName))
                                                <div><i class="bi bi-building me-1"></i> {{ $circlecalls['member']->companyName }}
                                                </div>
                                            @endif
                                            @if (!empty($circlecalls['member']->bCategory->categoryName))
                                                <div><i class="bi bi-tag me-1"></i> {{ $circlecalls['member']->bCategory->categoryName }}</div>
                                            @endif
                                        </div>

                                        <div class="mt-auto">
                                            <!-- Connect Button -->
                                            @php
                                                $connectionStatus = $circlecalls['member']->connection_status ?? 'Not Connected';
                                            @endphp
                                            @if ($connectionStatus == 'Connected')
                                                <button type="button" class="fb-btn fb-btn-disabled">Connected</button>
                                            @elseif ($connectionStatus == 'Accepted')
                                                <button class="fb-btn fb-btn-primary">Message</button>
                                            @elseif ($connectionStatus == 'Pending')
                                                <button type="button" class="fb-btn fb-btn-disabled">Requested</button>
                                            @else
                                                <form action="{{ route('connect') }}" method="POST" class="d-block w-100">
                                                    @csrf
                                                    <input type="hidden" value="{{ $circlecalls['member']->id }}" name="memberId">
                                                    <button type="submit" class="fb-btn fb-btn-primary">Connect</button>
                                                </form>
                                            @endif

                                            <!-- View Profile -->
                                            <a href="{{ route('foundPersonDetails', $circlecalls['member']->id) }}" class="text-decoration-none d-block w-100">
                                                <button class="fb-btn fb-btn-secondary">View Profile</button>
                                            </a>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        {{-- Card 2: Top Business Leader --}}
                        @if ($busGiver)
                            <div class="col-sm-6 col-lg-4">
                                <div class="fb-card shadow-sm">
                                    <div class="fb-card-img-wrapper">
                                        <span class="fb-badge">Top Business Leader</span>
                                        <img src="{{ asset('ProfilePhoto/' . ($busGiver['member']->profilePhoto ?? 'profile.png')) }}" class="fb-card-img" alt="Profile Image">
                                    </div>
                                    <div class="fb-card-body">
                                        <h5 class="fb-card-title">{{ $busGiver['member']->firstName }} {{ $busGiver['member']->lastName }}</h5>

                                        <div class="fb-card-subtitle">
                                            <i class="bi bi-people-fill"></i>
                                            {{ $busGiver['member']->circle->circleName ?? 'N/A' }}
                                            <span>&bull;</span>
                                            {{-- <span>Business Given: {{ $busGiver['count'] }}</span> --}}
                                        </div>

                                        <div class="fb-card-info">
                                            <div><i class="bi bi-currency-rupee me-1"></i> {{ $busGiver['amount'] }}</div>
                                            @if (!empty($busGiver['member']->companyName))
                                                <div><i class="bi bi-building me-1"></i> {{ $busGiver['member']->companyName }}
                                                </div>
                                            @endif
                                            @if (!empty($busGiver['member']->bCategory->categoryName))
                                                <div><i class="bi bi-tag me-1"></i> {{ $busGiver['member']->bCategory->categoryName }}</div>
                                            @endif
                                        </div>

                                        <div class="mt-auto">
                                            <!-- Connect Button -->
                                            @php
                                                $connectionStatus = $busGiver['member']->connection_status ?? 'Not Connected';
                                            @endphp
                                            @if ($connectionStatus == 'Connected')
                                                <button type="button" class="fb-btn fb-btn-disabled">Connected</button>
                                            @elseif ($connectionStatus == 'Accepted')
                                                <button class="fb-btn fb-btn-primary">Message</button>
                                            @elseif ($connectionStatus == 'Pending')
                                                <button type="button" class="fb-btn fb-btn-disabled">Requested</button>
                                            @else
                                                <form action="{{ route('connect') }}" method="POST" class="d-block w-100">
                                                    @csrf
                                                    <input type="hidden" value="{{ $busGiver['member']->id }}" name="memberId">
                                                    <button type="submit" class="fb-btn fb-btn-primary">Connect</button>
                                                </form>
                                            @endif
                                            <!-- View Profile -->
                                            <a href="{{ route('foundPersonDetails', $busGiver['member']->id) }}" class="text-decoration-none d-block w-100">
                                                <button class="fb-btn fb-btn-secondary">View Profile</button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        {{-- Card 3: Top Reference Giver --}}
                        @if ($refGiver)
                            <div class="col-sm-6 col-lg-4">
                                <div class="fb-card shadow-sm">
                                    <div class="fb-card-img-wrapper">
                                        <span class="fb-badge">Top Reference Giver</span>
                                        <img src="{{ asset('ProfilePhoto/' . ($refGiver['member']->profilePhoto ?? 'profile.png')) }}" class="fb-card-img" alt="Profile Image">
                                    </div>
                                    <div class="fb-card-body">
                                        <h5 class="fb-card-title">{{ $refGiver['member']->firstName }} {{ $refGiver['member']->lastName }}</h5>

                                        <div class="fb-card-subtitle">
                                            <i class="bi bi-people-fill"></i>
                                            {{ $refGiver['member']->circle->circleName ?? 'N/A' }}
                                            <span>&bull;</span>
                                            <span>References Given: {{ $refGiver['count'] ?? '0' }}</span>
                                        </div>

                                        <div class="fb-card-info">
                                            @if (!empty($refGiver['member']->companyName))
                                                <div><i class="bi bi-building me-1"></i> {{ $refGiver['member']->companyName }}</div>
                                            @endif
                                            @if (!empty($refGiver['member']->bCategory->categoryName))
                                                <div><i class="bi bi-tag me-1"></i> {{ $refGiver['member']->bCategory->categoryName }}</div>
                                            @endif
                                        </div>

                                        <div class="mt-auto">
                                            <!-- Connect Button -->
                                            @php
                                                $connectionStatus = $refGiver['member']->connection_status ?? 'Not Connected';
                                            @endphp
                                            @if ($connectionStatus == 'Connected')
                                                <button type="button" class="fb-btn fb-btn-disabled">Connected</button>
                                            @elseif ($connectionStatus == 'Accepted')
                                                <button class="fb-btn fb-btn-primary">Message</button>
                                            @elseif ($connectionStatus == 'Pending')
                                                <button type="button" class="fb-btn fb-btn-disabled">Requested</button>
                                            @else
                                                <form action="{{ route('connect') }}" method="POST" class="d-block w-100">
                                                    @csrf
                                                    <input type="hidden" value="{{ $refGiver['member']->id }}" name="memberId">
                                                    <button type="submit" class="fb-btn fb-btn-primary">Connect</button>
                                                </form>
                                            @endif

                                            <!-- View Profile -->
                                            <a href="{{ route('foundPersonDetails', $refGiver['member']->id) }}" class="text-decoration-none d-block w-100">
                                                <button class="fb-btn fb-btn-secondary">View Profile</button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>


                @if (count($nearestEvents) != 0)
                    <div class="bg-light py-5">
                        <div class="upcoming-events">
                            <!-- Header -->
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4 class="fw-bold" style="color: #1d3268;">Upcoming Events</h4>
                                <a href="#" class="fw-bold text-decoration-none" style="color: #1d3268;">See All</a>
                            </div>

                            <!-- Horizontal Scrollable Cards -->
                            <div class="events-container d-flex">
                                @foreach ($nearestEvents as $event)
                                    <div class="event-card">
                                        <a href="{{ route('events.details', $event->id) }}" class="text-decoration-none">
                                            <img src="{{ $event->event_banner ? url('Event/' . $event->event_banner) : asset('images/event_default.png') }}" alt="{{ $event->title }}">

                                            <!-- Event Info Overlay -->
                                            <div class="event-info">
                                                <h6 class="fw-bold">{{ $event->title }}</h6>
                                                <small class="fw-bold">📍 {{ $event->venue }}</small>
                                                {{-- <small>📍 {{ $event->venue }}, {{ $event->location }}</small> --}}
                                            </div>

                                            <!-- Event Details -->
                                            <div class="event-details d-flex justify-content-between align-items-center text-muted small">
                                                <span class="fw-bold" style="color: #1d3268;">{{ \Carbon\Carbon::parse($event->date)->format('d M Y') }} | {{ \Carbon\Carbon::parse($event->start_time)->format('H:i') }} To {{ \Carbon\Carbon::parse($event->end_time)->format('H:i') }}</span>
                                                {{-- <span>⏳ Time {{ $event->duration }}</span> --}}
                                                <span class="price-tag fw-bold">₹ {{ $event->fees }}</span>
                                            </div>
                                        </a>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                @else
                    <style>
                        .upcoming-events {
                            display: none;
                        }
                    </style>
                    {{-- <div class="bg-light py-5">
                <div class="upcoming-events">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold" style="color: #1d3268;">Upcoming Events</h4>
                    </div>
                    <p class="text-muted text-center"><b>No Events for now.</b></p>
                </div>
            </div> --}}
                @endif


                @if (count($nearestTraining) != 0)
                    <div class="bg-light py-5">
                        <div class="upcoming-events trainings">
                            <!-- Header -->
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4 class="fw-bold" style="color: #1d3268;">Upcoming Training Workshops</h4>
                                <a href="#" class="fw-bold text-decoration-none" style="color: #1d3268;">See All</a>
                            </div>

                            <!-- Horizontal Scrollable Cards -->
                            <div class="events-container d-flex">
                                @foreach ($nearestTraining as $trainings)
                                    <div class="event-card">
                                        {{-- <a href="{{ route('events.details', $trainings->id) }}" class="text-decoration-none">
                                --}}
                                        <img src="{{ $trainings->training_banner ? url('Training/' . $trainings->training_banner) : asset('images/profile.png') }}" alt="{{ $trainings->title }}">

                                        <!-- Event Info Overlay -->
                                        <div class="event-info">
                                            <h6 class="fw-bold">{{ $trainings->title }}</h6>
                                            <small class="fw-bold">📍 {{ $trainings->venue }}</small>
                                            {{-- <small>📍 {{ $trainings->venue }}, {{ $trainings->location }}</small> --}}
                                        </div>

                                        <!-- Event Details -->
                                        <div class="event-details d-flex justify-content-between align-items-center text-muted small">
                                            <span class="fw-bold" style="color: #1d3268;">{{ \Carbon\Carbon::parse($trainings->date)->format('d M Y') }} | {{ \Carbon\Carbon::parse($trainings->start_time)->format('H:i') }} To {{ \Carbon\Carbon::parse($trainings->end_time)->format('H:i') }}</span>
                                            {{-- <span>⏳ Time {{ $trainings->duration }}</span> --}}
                                            <span class="price-tag fw-bold">₹ {{ $trainings->fees }}</span>
                                        </div>
                                        </a>
                                    </div>

                                    <!-- Event Details -->
                                    <div class="event-details d-flex justify-content-between align-items-center text-muted small">
                                        <span class="fw-bold" style="color: #1d3268;">{{ \Carbon\Carbon::parse($trainings->date)->format('d M Y') }} | {{ \Carbon\Carbon::parse($trainings->start_time)->format('H:i') }} To {{ \Carbon\Carbon::parse($trainings->end_time)->format('H:i') }}</span>
                                        {{-- <span>⏳ Time {{ $trainings->duration }}</span> --}}
                                        <span class="price-tag fw-bold">₹ {{ $trainings->fees }}</span>
                                    </div>
                                    </a>
                            </div>
                @endforeach
            </div>
        </div>
    </div>
@else
    <style>
        .upcoming-events .trainings {
            display: none;
        }
    </style>
    {{-- <div class="bg-light py-5">
            <div class="upcoming-events trainings">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="fw-bold" style="color: #1d3268;">Upcoming Training Workshops</h4>
                </div>
                <p class="text-muted text-center"><b>No Training Workshops for now.</b></p>
            </div>
        </div> --}}
    @endif



    </div>

    <!-- Right Section (5 Columns) -->
    <div class="col-lg-4 col-md-12">
        <div class="row">
            @if ($categoryNames->isNotEmpty())
                <div class="card shadow-sm p-4 text-center">
                    <h4 class="mb-4 fw-bold">Vacant Categories</h4>
                    <div class="row">
                        @foreach ($categoryNames as $categoryName)
                            <div class="col-md-6 mb-3">
                                <div class="card bottom-card border rounded p-2 pt-2" width="100%">
                                    <h5 class="m-0 card-text fw-bold">{{ $categoryName }}</h5>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif
            @if ($meeting == null)
                <div class="col-lg-12 col-md-12">
                    <div class="card shadow-sm p-4 text-center">
                        <h4 class="mb-4 fw-bold">Upcoming Circle Meetings</h4>
                        <div class="alert alert-info" role="alert">
                            No upcoming circle meeting found
                        </div>
                    </div>
                </div>
            @else
                <div class="col-lg-12 col-md-12">
                    <div class="card circleMeeting shadow-sm p-4 ">
                        <h4 class="mb-4 fw-bold" style="font-size: 18px; color:#1d3268;">&nbsp;Upcoming {{ $meeting->circle->circleName }} Circle Meetings
                        </h4>
                        <div class="card event-card-upcoming shadow-sm p-3 mb-3">
                            <div class="d-flex justify-content-between align-items-center">
                                {{-- <span class="fw-bold">1.</span> --}}
                                {{-- <div class="fw-bold" style="color: #1d3268;"></div> --}}
                                <span class="fw-bold">{{ $meeting->date->format('j M Y') }} | {{ $meeting->meetingTime }}</span>
                                <i class="bi bi-clipboard" onclick="copyMeetingLink()"></i>
                                <button class="btn btn-outline-primary btn-sm" onclick="openInvitePage('{{ $signedUrl }}')">Invite</button>
                            </div>
                            {{-- <div class="d-flex align-items-center mt-2">
                            <i class="bi bi-clock me-2"></i> 2 Hours
                        </div> --}}
                            <div class="d-flex align-items-center mt-2">
                                {{-- <i class="bi bi-people-fill me-2 text-muted"></i> <span class="fw-bold text-muted">{{ $meeting->circle->members->count() }}</span> --}}
                                <i class="bi bi-people-fill me-2 text-muted"></i>
                                <span class="fw-bold text-muted">
                                    {{ $meeting->circle->members->where('status', 'Active')->count() }}
                                </span>
                            </div>
                            <div class="d-flex align-items-center">
                                <i class="bi bi-geo-alt-fill me-2 text-muted"></i> <span class="fw-bold text-muted">{{ $meeting->circle->city->cityName }}</span>
                            </div>
                            <hr>
                            <div class="text-primary fw-semibold" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                Invited People - {{ $myInvites->count() }} <i class="bi bi-chevron-down"></i>
                            </div>
                            <div class="collapse" id="collapseExample">
                                <table class="table mt-2">
                                    <tbody>
                                        @foreach ($myInvites as $invite)
                                            <tr>
                                                <td><small class="text-muted">{{ $invite->personName }}</small>
                                                </td>
                                                <td><small class="text-muted">{{ $invite->personEmail }}</small>
                                                </td>
                                                <td><small class="text-muted">{{ $invite->personContact }}</small>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" id="shareableMeetingLink" value="{{ URL::signedRoute('visitor.form', ['slug' => $meeting->cm_slug, 'meetingId' => $meeting->id, 'ref' => auth()->user()->member->id]) }}">
            @endif


            <script>
                function copyMeetingLink() {
                    var copyText = document.getElementById("shareableMeetingLink").value;
                    navigator.clipboard.writeText(copyText).then(function() {
                        Swal.fire({
                            icon: 'success',
                            title: 'Link copied!',
                            text: 'The link has been copied to your clipboard.',
                            confirmButtonText: 'OK'
                        });
                    }, function(err) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Could not copy the link. Please try again.',
                            confirmButtonText: 'OK'
                        });
                    });
                }

                function openInvitePage(url) {
                    window.open(url, '_blank');
                }
            </script>

        </div>
    </div>
    </div>
    </div>

@endrole
