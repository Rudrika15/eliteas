@extends('layouts.master')

@section('header', 'Visitor')
@section('content')

<div class="card">
    <div class="card-body d-flex justify-content-between align-items-center">
        <h5 class="card-title">Edit Visitor</h5>
        <a href="{{ route('visitors.index') }}" class="btn btn-bg-orange btn-sm">BACK</a>
    </div>

    <!-- Floating Labels Form -->
    <form class="m-3 needs-validation" id="visitorsForm" enctype="multipart/form-data" method="post"
        action="{{ route('visitors.update', $visitors->id) }}" novalidate>
        @csrf
        <input type="hidden" name="id" value="{{ $visitors->id }}">
        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" class="form-control" id="firstName" name="firstName" placeholder="First Name"
                        required value="{{ $visitors->firstName }}">
                    <label for="firstName">First Name</label>
                    @error('firstName')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" class="form-control" id="lastName" name="lastName" placeholder="Last Name"
                        required value="{{ $visitors->lastName }}">
                    <label for="lastName">Last Name</label>
                    @error('lastName')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" class="form-control" id="mobileNo" name="mobileNo" placeholder="Contact No"
                        required value="{{ $visitors->mobileNo }}">
                    <label for="mobileNo">Mobile No</label>
                    @error('mobileNo')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="email" class="form-control" id="email" name="email" placeholder="Email"
                        value="{{ $visitors->email }}" required>
                    <label for="email">Email</label>
                    @error('email')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" class="form-control" id="businessName" name="businessName"
                        placeholder="Business Name" required value="{{ $visitors->businessName }}">
                    <label for="businessName">Business Name</label>
                    @error('businessName')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-floating">
                    <select class="form-select" id="businessCategory" name="businessCategory" required>
                        <option value="">Select Business Category</option>
                        @foreach ($businessCategories as $category)
                        <option value="{{ $category->id }}" {{ old('businessCategory', $visitors->businessCategory) ==
                            $category->id ? 'selected' : '' }}>{{ $category->categoryName }}</option>
                        @endforeach
                    </select>
                    <label for="businessCategory">Business Category</label>
                    @error('businessCategory')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" class="form-control" id="invitedBy" name="invitedBy" placeholder="Invited By"
                        required value="{{ $visitors->invitedBy }}">
                    <label for="invitedBy">Invited By</label>
                    @error('invitedBy')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-floating">
                    <textarea class="form-control" id="remarks" name="remarks"
                        placeholder="Remarks">{{ old('remarks', $visitors->remarks) }}</textarea>
                    <label for="remarks">Remarks</label>
                    @error('remarks')
                    <div class="invalid-tooltip">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-bg-blue">Submit</button>
        </div>
    </form><!-- End floating Labels Form -->
</div>

@endsection