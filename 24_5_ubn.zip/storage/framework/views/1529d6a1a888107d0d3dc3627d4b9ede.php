

<?php $__env->startSection('header', 'Franchise'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">Country</h4>
            <a href="<?php echo e(route('country.create')); ?>" class="btn btn-bg-orange btn-sm mt-3"><i class="bi bi-plus-circle"></i></a>
        </div>

        <!-- Table with stripped rows -->
        <table class="table datatable">
            <thead>
                <tr>
                    <th>Country Name</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($countryData->countryName); ?></td>
                    <td><?php echo e($countryData->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('country.edit', $countryData->id)); ?>" class="btn btn-bg-blue btn-sm">
                            <i class="bi bi-pen"></i>
                        </a>

                        

                        <a href="<?php echo e(route('country.delete', $countryData->id)); ?>" class="btn btn-danger btn-sm">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/country/index.blade.php ENDPATH**/ ?>