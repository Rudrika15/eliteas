

<?php $__env->startSection('header', 'Train Master'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body d-flex justify-content-between align-items-center">
        <h5 class="card-title">Edit Train Master</h5>
        <a href="<?php echo e(route('trainer.index')); ?>" class="btn btn-secondary btn-sm">BACK</a>
    </div>

    <!-- Floating Labels Form -->
    <form class="m-3 needs-validation" id="trainmasterForm" enctype="multipart/form-data" method="post"
        action="<?php echo e(route('trainer.update', $trainer->id)); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($trainer->id); ?>">
        <div class="row">
            <div class="col-md-6">
                <!-- Trainer selection -->
                <div class="form-check">
                    <input class="form-check-input trainer-radio" type="radio" name="type" id="internal" value="internalMember"
                        checked=<?php echo e($trainer->type == 'internalMember' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="internalMember">Internal</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input trainer-radio" type="radio" name="type" id="external" value="externalMember"
                        <?php echo e($trainer->type == 'externalMember' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="externalMember">External</label>
                </div>
        
                <!-- Member selection -->
                <div class="member-list" id="memberListDropdownMember">
                    <?php echo $__env->make('InternalTrainer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <input type="hiddden" name="trainerId" id="trainerId" value="<?php echo e($trainer->userId); ?>">
                    <input type="text" class="form-control mt-3" id="trainerName" name="memberName" placeholder="Select Member"
                        readonly value="<?php echo e($trainer->user->firstName); ?> <?php echo e($trainer->user->lastName); ?>">
                    <input type="text" class="form-control mt-3" id="trainerContact" name="contactNo" placeholder="Contact No"
                        readonly value="<?php echo e($trainer->user->contactNo); ?>">
                    <input type="text" class="form-control mt-3" id="trainerEmail" name="email" value="<?php echo e($trainer->user->email); ?>" placeholder="Email" readonly>
                </div>
                
                    
                    
        
                <!-- Contact details -->
            </div>
        </div>
        
        
        
        
        
        <div class="row mb-3 externalTrainer">
            <br>
            <b>External Trainer Details</b>
            <div class="col-md-6">
                <div class="form-floating mt-3">
                    <input type="text" class="form-control <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="firstName"
                        name="firstName" placeholder="Train Name" value="<?php echo e($trainer->user->firstName); ?>">
                    <label for="firstName">First Name</label>
                    <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        
            <div class="col-md-6">
                <div class="form-floating mt-3">
                    <input type="text" class="form-control <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lastName"
                        name="lastName" placeholder="Train Name" value="<?php echo e($trainer->user->lastName); ?>">
                    <label for="lastName">Last Name</label>
                    <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        
            <div class="col-md-6">
                <div class="form-floating mt-3">
                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email"
                        placeholder="Train Name" value="<?php echo e($trainer->user->email); ?>">
                    <label for="email">Email</label>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        
            <div class="col-md-6">
                <div class="form-floating mt-3">
                    <input type="text" class="form-control <?php $__errorArgs = ['contactNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="contactNo"
                        name="contactNo" placeholder="Contact No" value="<?php echo e($trainer->user->contactNo); ?>">
                    <label for="contactNo">Contact No</label>
                    <?php $__errorArgs = ['contactNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        
        
        </div>
        <div class="text-center mt-5">
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="reset" class="btn btn-secondary">Reset</button>
        </div>
    </form><!-- End floating Labels Form -->
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    $(document).ready(function(){
        $('.externalTrainer').hide();

        $('.trainer-radio').change(function(){
            var selectedVal = $(this).val();

            if(selectedVal == 'externalMember'){
                $('.member-list').hide();
                $('.externalTrainer').show();
            }else{
                $('.member-list').show();
                $('.externalTrainer').hide();
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/trainerMaster/edit.blade.php ENDPATH**/ ?>