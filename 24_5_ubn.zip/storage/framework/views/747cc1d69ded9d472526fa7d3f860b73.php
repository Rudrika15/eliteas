

<?php $__env->startSection('header', 'Invited People List'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">Circle Meeting Invited Person List</h4>
            
        </div>

        <!-- Table with stripped rows -->
        <div class="table-responsive">
            <table class="table mt-3">
                <thead>
                    <tr>
                        <th>Invited By</th>
                        <th>Person Name</th>
                        <th>Person Email</th>
                        <th>Payment Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invitedPersonList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitedPersonListData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($invitedPersonListData->user->member->firstName ?? '-'); ?> <?php echo e($invitedPersonListData->user->member->lastName ?? '-'); ?></td>
                        <td><?php echo e($invitedPersonListData->personName ?? '-'); ?></td>
                        <td><?php echo e($invitedPersonListData->personEmail ?? '-'); ?></td>
                        <?php
                        $statusColors = [
                        'Pending' => 'red',
                        'Accepted' => 'green',
                        'Rejected' => 'red',
                        ];
                        ?>
                        <td
                            style="background-color: <?php echo e($statusColors[$invitedPersonListData->paymentStatus] ?? 'red'); ?>; color: white;">
                            <?php echo e(Str::ucfirst($invitedPersonListData->paymentStatus)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- End Table with stripped rows -->
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/schedule/invitedList.blade.php ENDPATH**/ ?>