<?php $__env->startSection('title', 'UBN - Referance Giver'); ?>
<?php $__env->startSection('content'); ?>

    
    <?php if(Session::has('success')): ?>
        <div id="successMessage" class="alert alert-success alert-dismissible" role="alert">
            
            <strong>Success !</strong> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible" id="error-alert" role="alert">
            <button type="button" class="close" data-dismiss="alert">
                
            </button>
            <strong>Error !</strong> <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>



    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-5">
                <h4 class="mb-0 mt-3 text-blue">Reference Giver</h4>
                <a href="<?php echo e(route('refGiver.create')); ?>" class="btn btn-bg-orange btn-sm mt-3"><i class="bi bi-plus-circle"></i></a>
            </div>
            <hr>
            <!-- Table with stripped rows -->
            <div class="table-responsive mt-5 ">
                <table class="table datatable mb-5">
                    <thead>
                        <tr>

                            <th >Member Name</th>
                            
                            <th>Ex.Contact Name</th>
                            <th>Ex.Contact No</th>
                            <th>Ex.Email</th>
                            <th>Scale</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $refGiver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refGiverData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($refGiverData->members->firstName ?? '-'); ?>

                                    <?php echo e($refGiverData->members->lastName ?? '-'); ?>

                                </td>
                                
                                <td><?php echo e($refGiverData->contactName ?? '-'); ?></td>
                                <td><?php echo e($refGiverData->contactNo ?? '-'); ?></td>
                                <td><?php echo e($refGiverData->email ?? '-'); ?></td>
                                <td><?php echo e($refGiverData->scale ?? '-'); ?></td>
                                <td><?php echo e($refGiverData->description ?? '-'); ?></td>
                                <td><?php echo e($refGiverData->status); ?></td>
                                <td class="d-flex gap-1">
                                    <a href="<?php echo e(route('refGiver.edit', $refGiverData->id)); ?>"
                                        class="btn btn-bg-blue btn-sm">
                                        <i class="bi bi-pen"></i>
                                    </a>
                                    <a onclick="return confirm('Do You Want To Delete It')"
                                        href="<?php echo e(route('refGiver.delete', $refGiverData->id)); ?>"
                                        class="btn btn-danger btn-sm">
                                        <i class="bi bi-trash"></i>
                                    </a>


                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- End Table with stripped rows -->
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/refGiver/index.blade.php ENDPATH**/ ?>