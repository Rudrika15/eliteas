<?php $__env->startSection('title', 'UBN - 1:1 Meeting'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>


<div class="card">
    <div class="card-body d-flex justify-content-between align-items-center">
        <h5 class="card-title">Edit Call Meeting</h5>
        <a href="<?php echo e(route('circlecall.index')); ?>" class="btn btn-bg-orange btn-sm">BACK</a>
    </div>
    <hr>
    <!-- Floating Labels Form -->
    <form class="m-3 needs-validation" id="callForm" enctype="multipart/form-data" method="post"
        action="<?php echo e(route('circlecall.update', $circlecall->id)); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($circlecall->id); ?>">


        <?php echo $__env->make('circleMemberMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row mb-3 mt-3">
            <div class="col-md-12">
                <div class="form-floating mt-3">
                    <input type="hidden" id="meetingPersonId" name="meetingPersonId"
                        value="<?php echo e($circlecall->meetingPersonId); ?>">
                    <input type="text" class="form-control" readonly id="meetingPersonName" placeholder="Select Member"
                        value="<?php echo e($circlecall->meetingPerson->firstName); ?> <?php echo e($circlecall->meetingPerson->lastName); ?>">
                    <label for="memberName">Meeting Person Name</label>
                    <?php $__errorArgs = ['memberId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

        </div>

        
            
                <div class="form-floating mt-3">
                    <input type="text" class="form-control <?php $__errorArgs = ['meetingPlace'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="meetingPlace" name="meetingPlace" placeholder="Meeeting Place Name"
                        value="<?php echo e($circlecall->meetingPlace); ?>" required>
                    <label for="meetingPlace">Meeting Place Name</label>
                    <?php $__errorArgs = ['meetingPlace'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <div class="form-floating mt-3">
                        <?php
                            use Illuminate\Support\Carbon;
                                    
                            $nearestDate = $scheduleDate->min();
                            $nearestDate = $nearestDate ? Carbon::parse($nearestDate)->subDay()->format('Y-m-d') : Carbon::now()->format('Y-m-d');
                            // $startDate = Carbon::now()->subDay(15)->format('Y-m-d');
                            // $nearestDate = '2024-04-24';
                            // $startDate = $lastDate;
                            
                            ?>
                            
                        <input type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date"
                            name="date" placeholder="Meeting Date" required min="<?php echo e($lastDate); ?>"
                            max="<?php echo e($nearestDate); ?>" value="<?php echo e(old('date', $circlecall->date)); ?>">
                        <label for="date">Date</label>
                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-tooltip">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-floating mt-3">
                    <input type="text" class="form-control <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="remarks"
                        name="remarks" placeholder="Remarks" value="<?php echo e($circlecall->remarks); ?>" required>
                    <label for="remarks">Remarks</label>
                    <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="text-center mt-5 ">
                    <button type="submit" class="btn btn-bg-blue">Submit</button>
                    <button type="reset" class="btn btn-bg-orange">Reset</button>
                </div>

    </form><!-- End floating Labels Form -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/circlecall/edit.blade.php ENDPATH**/ ?>