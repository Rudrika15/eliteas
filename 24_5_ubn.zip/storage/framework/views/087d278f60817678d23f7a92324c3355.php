<?php $__env->startSection('title', 'UBN - Testimonial'); ?>

<?php $__env->startSection('content'); ?>

    
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert">
                
            </button>
            <strong>Success !</strong> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert">
                
            </button>
            <strong>Error !</strong> <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>


    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-5">
                <h4 class="text-blue ">Create Testimonial</h4>
                <a href="<?php echo e(route('testimonial.index')); ?>" class="btn btn-bg-blue btn-sm">BACK</a>
            </div>
            <hr class="mb-5">
            <form class="m-3 needs-validation" id="circlecallForm" enctype="multipart/form-data" method="post"
                action="<?php echo e(route('testimonial.store')); ?>" novalidate>
                <?php echo csrf_field(); ?>

                <!-- Button trigger modal -->

                <?php echo $__env->make('testimonialCircleMember', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="row mb-3 ">
                    <div class="col-md-12">
                        <div class="form-floating mt-3">
                            <input type="hidden" id="circlePersonId" name="circlePersonId">
                            <input type="text" class="form-control" id="circlePersonName" placeholder="Select Member"
                                disabled>
                            <label for="meetingPersonName">Circle Member Name</label>
                            <?php $__errorArgs = ['circlePersonId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-tooltip">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-floating mt-3">
                            <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="message" name="message"
                                placeholder="Enter Message"></textarea>
                            <label for="message">Message</label>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-tooltip">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!-- Hidden field to store the selected member's ID -->


                    



                </div>
                <div class="text-center mt-5">
                    <button type="submit" class="btn btn-bg-blue">Submit</button>
                    <button type="reset" class="btn btn-bg-orange">Reset</button>
                </div>
            </form><!-- End floating Labels Form -->
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/testimonial/create.blade.php ENDPATH**/ ?>