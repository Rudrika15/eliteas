

<?php $__env->startSection('header', 'Trainer Master'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">Trainer Master</h4>
            <a href="<?php echo e(route('trainer.create')); ?>" class="btn btn-bg-orange btn-sm mt-3"><i class="bi bi-plus-circle"></i></a>
        </div>

        <!-- Table with stripped rows -->
        <table class="table datatable">
            <thead>
                <tr>
                    <th>Trainer Name</th>
                    <th>Type</th>
                    <th>Contact No</th>
                    <th>status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $trainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainerData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($trainerData->user->firstName); ?> <?php echo e($trainerData->user->lastName); ?></td>
                    <td><?php if($trainerData->type == 'internalMember'): ?>
                        Internal Member
                    <?php elseif($trainerData->type == 'externalMember'): ?>
                        External Trainer
                    <?php endif; ?>
                    </td>
                    <td><?php echo e($trainerData->users->contactNo ?? $trainerData->externalMemberContact ?? '-'); ?> </td>
                    <td><?php echo e($trainerData->status); ?></td>

                    <td>
                        
            
                        <a href="<?php echo e(route('trainer.delete', $trainerData->id)); ?>" class="btn btn-danger btn-sm">
                            <i class="bi bi-trash"></i>
                        </a>
            
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/trainerMaster/index.blade.php ENDPATH**/ ?>