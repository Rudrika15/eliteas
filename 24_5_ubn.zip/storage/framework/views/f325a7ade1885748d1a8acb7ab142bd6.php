

<?php $__env->startSection('header', 'Subscriptions'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">All Subscriptions</h4>
            
        </div>

        <!-- Table with stripped rows -->
        <table class="table datatable">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Membership Type</th>
                    <th>Amount</th>
                    <th>Validity</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $allSubscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscritptionsData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($subscritptionsData->user->firstName ?? '-'); ?> <?php echo e($subscritptionsData->user->lastName ?? '-'); ?></td>
                    <td><?php echo e($subscritptionsData->membershipType ?? '-'); ?></td>
                    <td><?php echo e($subscritptionsData->allPayments->amount ?? '-'); ?></td>
                    <td><?php echo e($subscritptionsData->validity ?? '-'); ?></td>
                    <td><?php echo e($subscritptionsData->status ?? '-'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>


    <?php $__env->stopSection(); ?>





<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">All Subscriptions</h4>
            
        </div>

        <!-- Table with stripped rows -->
        
        <!-- End Table with stripped rows -->
    </div>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/mysubscriptions/adminIndex.blade.php ENDPATH**/ ?>