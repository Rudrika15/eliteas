<?php $__env->startSection('title', 'UBN - Circle Business'); ?>
<?php $__env->startSection('content'); ?>



        

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <h4 class="mb-0 mt-3 text-blue">Circle Member Business</h4>
            
        </div>
        <hr class="mb-5">
        <!-- Table with stripped rows -->
        <table class="table datatable mb-5">
            <thead>
                <tr>
                    <th>Business Giver</th>
                    
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $busGiver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $busGiverData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($busGiverData->businessGiver->firstName . ' ' . $busGiverData->businessGiver->lastName ?? '-'); ?>

                    </td>
                    
                    <td><?php echo e($busGiverData->amount ?? '-'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($busGiverData->date)->format('d-m-Y') ?? '-'); ?></td>
                    <td><?php echo e($busGiverData->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('busGiver.edit', $busGiverData->id)); ?>" class="btn btn-bg-orange btn-sm">
                            <i class="bi bi-plus"></i>
                        </a>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/circlebusiness/index.blade.php ENDPATH**/ ?>