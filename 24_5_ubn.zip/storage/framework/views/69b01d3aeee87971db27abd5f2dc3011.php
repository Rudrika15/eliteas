

<?php $__env->startSection('content'); ?>

<style>
    .badge-success {
        color: #0055ff;
        /* Change text color to white */
    }

    .card-title {
        font-size: 1.25rem;
        font-weight: bold;
        margin-bottom: 0;
    }

    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }

    .card-body {
        padding: 1.25rem;
    }

    .btn-back {
        color: #fff;
        background-color: #007bff;
        border-color: #007bff;
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        line-height: 1.5;
        border-radius: 0.25rem;
    }

    .btn-back:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }
</style>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h2 class="card-title m-0">Show User</h2>
        <a class="btn btn-back" href="<?php echo e(route('users.index')); ?>">Back</a>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>First Name:</strong>
                    <?php echo e($user->firstName); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <strong>Last Name:</strong>
                    <?php echo e($user->lastName); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <strong>Email:</strong>
                    <?php echo e($user->email); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <strong>Roles:</strong>
                    <?php if(!empty($user->getRoleNames())): ?>
                    <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="badge badge-success"><?php echo e($v); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if($user->hasRole('Member')): ?>
        <div class="row">
            <div class="col-lg-12 mt-3">
                <div class="text-right">
                    <a class="btn btn-primary" href="<?php echo e(route('members.show', $user->id)); ?>">Show Full Profile</a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/users/show.blade.php ENDPATH**/ ?>