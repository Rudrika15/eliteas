<?php $__env->startSection('title', 'UBN - Referance Giver'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        input[type=range]::-webkit-slider-thumb {

            background-color: #1d2856;

        }
    </style>
    
    <?php if(Session::has('success')): ?>
        <div id="success-alert" class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert">
                
            </button>
            <strong>Success !</strong> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible" id="error-alert" role="alert">
            <button type="button" class="close" data-dismiss="alert">
                
            </button>
            <strong>Error !</strong> <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <script>
        $(document).ready(function() {
            // Hide success message after 2 seconds
            $('#success-alert').delay(2000).fadeOut('slow');

            // Hide error message after 2 seconds
            $('#error-alert').delay(2000).fadeOut('slow');
        });
    </script>

    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-5">
                <h4 class="text-blue">Edit Circle Meeting Member Refference</h4>
                <a href="<?php echo e(route('refGiver.index')); ?>" class="btn btn-bg-blue btn-sm ">BACK</a>
            </div>
            <hr class="mb-5">

            <!-- Floating Labels Form -->
            <form class="m-3 needs-validation" id="meetingMemberRefForm" enctype="multipart/form-data" method="post"
                action="<?php echo e(route('refGiver.update', $refGiver->id)); ?>" novalidate>
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="group" id="internal" value="internal"
                                checked="">
                            <label class="form-check-label" for="internal">
                                Internal
                            </label>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="group" id="external" value="external"
                                <?php echo e($refGiver->contactName ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="external">
                                External
                            </label>
                        </div>
                    </div>
                </div>
                
                
                
                <div class="col-md-4 mb-3 mt-3">
                    <?php echo $__env->make('circleMemberMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                
                <input type="hidden" id="meetingPersonId" name="memberId" value="<?php echo e($refGiver->memberId); ?>">
                <div class="form-floating">

                    <!-- Searchable input field -->
                    <input type="text" class="form-control" id="meetingPersonName" name="memberName"
                        placeholder="Select Member"
                        value="<?php echo e($refGiver->members->firstName . ' ' . $refGiver->members->lastName ?? '-'); ?>" readonly>
                    <label for="memberName">Member Name</label>
                    <?php $__errorArgs = ['memberId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-tooltip">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                

                
                <div class="mt-3">
                    <div class="form-floating ">
                        <input type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="description" name="description" placeholder="description"
                            value="<?php echo e($refGiver->description); ?>" required>
                        <label for="description">Description</label>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-tooltip">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                
                

                



                
                
                <div class="" id="memberListInput" style="display:none;">
                    <h4 class="mt-3 text-blue">Contact Person Details</h4>


                    <div class="form-floating mt-3">
                        <input type="text" class="form-control <?php $__errorArgs = ['contactName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id=""
                            name="contactNameExternal" placeholder="Contact Name" value="<?php echo e($refGiver->contactName); ?>">
                        <label for="contactName">Contact Person Name</label>
                        <?php $__errorArgs = ['contactName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-tooltip">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="">
                        <div class="form-floating mt-3">
                            <input type="text"
                                class="form-control <?php $__errorArgs = ['contactNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> selectedMemberContact"
                                id="contactPersonContact" name="contactNo" value="<?php echo e($refGiver->contactNo); ?>"
                                placeholder="Contact No">
                            <label for="contactNo">Contact No</label>
                            <?php $__errorArgs = ['contactNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-tooltip">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="">
                        <div class="form-floating mt-3">
                            <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="contactPersonEmail" name="email" value="<?php echo e($refGiver->email); ?>" placeholder="email">
                            <label for="email">Email</label>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-tooltip">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                



                



                <div class="mt-3  ">
                    <label for="scale">Scale [1-5]</label>
                    <div class="form-floating mt-3">
                        <input type="range" class="form-range  <?php $__errorArgs = ['scale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="scale"
                            name="scale" placeholder="scale" value="<?php echo e($refGiver->scale); ?>" required min="1"
                            max="5" step="1">
                        <div class="d-flex justify-content-between align-items-center mt-2">
                            <span class="badge btn-bg-blue rounded-pill">1</span>
                            <span class="badge btn-bg-blue rounded-pill">2</span>
                            <span class="badge btn-bg-blue rounded-pill">3</span>
                            <span class="badge btn-bg-blue rounded-pill">4</span>
                            <span class="badge btn-bg-blue rounded-pill">5</span>
                        </div>
                        <?php $__errorArgs = ['scale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-tooltip">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="text-center mt-5">
                    <button type="submit" class="btn btn-bg-blue">Submit</button>
                    <button type="reset" class="btn btn-bg-orange">Reset</button>
                </div>
            </form><!-- End floating Labels Form -->
        </div>
    </div>




    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" />
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var scaleInput = document.getElementById("scale");
            var scaleOutput = document.getElementById("scaleOutput");

            scaleInput.addEventListener("input", function() {
                scaleOutput.textContent = scaleInput.value;
            });
        });
    </script>



    <script type="text/javascript">
        var path = "<?php echo e(route('getMemberForRef')); ?>";

        $('#search').select2({
            placeholder: 'Select Member',
            ajax: {
                url: path,
                dataType: 'json',
                delay: 250,
                processResults: function(data) {
                    return {
                        results: $.map(data, function(item) {
                            return {
                                text: item.firstName,
                                id: item.id,
                                firstName: item
                                    .firstName // Adding firstName attribute to the option data
                            }
                        })
                    };
                },
                cache: true
            }
        });

        // Update the hidden input field with the selected member's ID
        $('#search').on('select2:select', function(e) {
            var data = e.params.data;
            $('#selectedMemberId').val(data.id);
            $('#memberName').val(data.firstName);
        });
    </script>


    

    <script>
        $(document).ready(function() {
            // Check if the "External" radio button is already checked on page load
            var initialValue = $('input[name="group"]:checked').attr("id");

            // Show/hide elements based on the initial state
            if (initialValue === "internal") {
                $("#memberListDropdown").show();
                $("#memberListInput").hide();
            } else if (initialValue === "external") {
                $("#memberListDropdown").hide();
                $("#memberListInput").show();
            }

            // Toggle elements when radio button is clicked
            $('input[type="radio"]').click(function() {
                var inputValue = $(this).attr("id");
                if (inputValue === "internal") {
                    $("#memberListDropdown").show();
                    $("#memberListInput").hide();
                    // $('.contactName').val('');
                    // $('.contactEmail').val('');
                } else if (inputValue === "external") {
                    $("#memberListDropdown").hide();
                    $("#memberListInput").show();
                }
            });
        });
    </script>




    <!-- Your JavaScript code to trigger inclusion of circleMemberMaster -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/refGiver/edit.blade.php ENDPATH**/ ?>