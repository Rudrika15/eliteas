

<?php $__env->startSection('header', 'Franchise'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">Next Upcoming Meetings</h4>
            
        </div>

        <!-- Table with stripped rows -->
        <table class="table datatable">
            <thead>
                <tr>
                    <th>Circle Name</th>
                    <th>Day</th>
                    <th>Date</th>
                    <th>Venue</th>
                    <th>Time</th>
                    <th>Remarks</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $closestMeetings = [];
                ?>
                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedulesData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $scheduleDate = \Carbon\Carbon::parse($schedulesData->date);

                if ($scheduleDate->isToday() || $scheduleDate->isFuture()) {

                $circleId = $schedulesData->circle->id;
                if (!isset($closestMeetings[$circleId]) ||

                $scheduleDate->lt($closestMeetings[$circleId]['date'])) {

                $closestMeetings[$circleId] = [

                'data' => $schedulesData,

                'date' => $scheduleDate,
                ];
                }
                }
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $closestMeetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($meeting['data']->circle->circleName); ?></td>
                    <td>
                        <?php
                        $dayIndex = $meeting['data']->day;
                        $days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        $dayName = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
                        ?>
                        <?php echo e($dayName); ?>

                    </td>
                    <td><?php echo e($meeting['data']->date); ?></td>
                    <td><?php echo e($meeting['data']->venue); ?></td>
                    <td><?php echo e($meeting['data']->meetingTime); ?></td>
                    <td><?php echo e($meeting['data']->remarks); ?></td>
                    <td><?php echo e($meeting['data']->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('schedule.invitedList', $meeting['data']->id)); ?>" class="btn btn-info btn-sm">
                            <i class="bi bi-person-lines-fill"></i>
                        </a>

                        <a href="<?php echo e(route('schedule.dashEdit', $meeting['data']->id)); ?>" class="btn btn-bg-blue btn-sm">
                            <i class="bi bi-pen"></i>
                        </a>

                        <a href="<?php echo e(route('schedule.delete', $meeting['data']->id)); ?>"
                            class="btn btn-danger btn-sm ">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/schedule/dashIndex.blade.php ENDPATH**/ ?>