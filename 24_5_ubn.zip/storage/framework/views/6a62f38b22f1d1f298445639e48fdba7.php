<?php $__env->startSection('title', 'UBN - Testimonial'); ?>
<?php $__env->startSection('content'); ?>

    
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert">
                
            </button>
            <strong>Success !</strong> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert">
                
            </button>
            <strong>Error !</strong> <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="mb-0 mt-3">Testmonial</h4>
                
            </div>

            <!-- Table with stripped rows -->
            <table class="table datatable">
                <thead>
                    <tr>
                        <th>Testimonial Giver</th>
                        <th>Testimonial Taker</th>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonialData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($testimonialData->user->firstName ?? '-'); ?> <?php echo e($testimonialData->user->lastName ?? '-'); ?>

                            </td>
                            <td><?php echo e($testimonialData->member->firstName ?? '-'); ?>

                                <?php echo e($testimonialData->member->lastName ?? '-'); ?></td>
                            <td><?php echo e($testimonialData->message); ?></td>
                            <td><?php echo e($testimonialData->uploadedDate); ?></td>
                            <td><?php echo e($testimonialData->status); ?></td>
                            <td>

                                <a href="<?php echo e(route('testimonial.restore', $testimonialData->id)); ?>"
                                    onclick="return confirm('Do You Want To restore It ?')"
                                    class="btn btn-success btn-sm d-flex justify-content-center align-items-center">Restore</a>
                            </td>
                            

                            


                            
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- End Table with stripped rows -->
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/testimonial/archives.blade.php ENDPATH**/ ?>