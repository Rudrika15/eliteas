

<?php $__env->startSection('header', 'Franchise'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">Franchise</h4>
            <a href="<?php echo e(route('franchise.create')); ?>" class="btn btn-bg-orange btn-sm mt-3"><i class="bi bi-plus-circle"></i></a>
        </div>

        <!-- Table with stripped rows -->
        <table class="table datatable">
            <thead>
                <tr>
                    <th>Franchise Name</th>
                    <th>Owner Name</th>
                    <th>City Name</th>
                    <th>Franchise Contact Details</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $franchises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $franchiseData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($franchiseData->franchiseName); ?></td>
                    <td><?php echo e($franchiseData->user ? $franchiseData->user->firstName.' '.$franchiseData->user->lastName :
                        '-'); ?></td>
                    <td><?php echo e($franchiseData->city->cityName ?? '-'); ?></td>
                    <td><?php echo e($franchiseData->franchiseContactDetails); ?></td>
                    <td><?php echo e($franchiseData->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('franchise.edit', $franchiseData->id)); ?>" class="btn btn-bg-blue btn-sm">
                            <i class="bi bi-pen"></i>
                        </a>

                        

                        <a href="<?php echo e(route('franchise.delete', $franchiseData->id)); ?>" class="btn btn-danger btn-sm">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/franchise/index.blade.php ENDPATH**/ ?>