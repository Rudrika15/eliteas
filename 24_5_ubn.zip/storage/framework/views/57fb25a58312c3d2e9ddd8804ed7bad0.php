<?php $__env->startComponent('mail::message'); ?>
# Welcome to UBN

Your username is: <?php echo e($username); ?>


Your password is: <?php echo e($password); ?>


Please keep this information secure.

Thank you,
The UBN Team
<?php echo $__env->renderComponent(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/emails/welcome_member.blade.php ENDPATH**/ ?>