

<?php $__env->startSection('header', 'Franchise'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">Meetings</h4>
            <a href="<?php echo e(route('circle.index')); ?>" class="btn btn-bg-orange btn-sm mt-3">BACK</a>
        </div>

        <!-- Table with stripped rows -->
        <table class="table datatable">
            <thead>
                <tr>
                    <th>Circle Name</th>
                    <th>Day</th>
                    <th>Date</th>
                    <th>Venue</th>
                    <th>Time</th>
                    <th>Remarks</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedulesData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($schedulesData->circle->circleName); ?></td>
                    <td>
                        
                        <?php if($schedulesData->day == 0): ?>
                        Sunday
                        <?php elseif($schedulesData->day == 1): ?>
                        Monday
                        <?php elseif($schedulesData->day == 2): ?>
                        Tuesday
                        <?php elseif($schedulesData->day == 3): ?>
                        Wednesday
                        <?php elseif($schedulesData->day == 4): ?>
                        Thursday
                        <?php elseif($schedulesData->day == 5): ?>
                        Friday
                        <?php elseif($schedulesData->day == 6): ?>
                        Saturday
                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($schedulesData->date); ?></td>
                    <td><?php echo e($schedulesData->venue); ?></td>
                    <td><?php echo e($schedulesData->meetingTime); ?></td>
                    <td><?php echo e($schedulesData->remarks); ?></td>
                    <td><?php echo e($schedulesData->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('schedule.invitedList', $schedulesData->id)); ?>" class="btn btn-info btn-sm">
                            <i class="bi bi-person-lines-fill"></i>
                        </a>

                        <a href="<?php echo e(route('schedule.edit', $schedulesData->id)); ?>" class="btn btn-bg-blue btn-sm ">
                            <i class="bi bi-pen"></i>
                        </a>

                        <a href="<?php echo e(route('schedule.delete', $schedulesData->id)); ?>" class="btn btn-danger btn-sm">
                            <i class="bi bi-trash"></i>
                        </a>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/circle/show.blade.php ENDPATH**/ ?>