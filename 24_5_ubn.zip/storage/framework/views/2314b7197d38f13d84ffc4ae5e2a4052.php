

<?php $__env->startSection('header', 'Circle'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">Circle</h4>
            <div class="">
                <a href="<?php echo e(route('circle.create')); ?>" class="btn btn-bg-orange btn-sm mt-3 mr-2 "><i
                        class="bi bi-plus-circle"></i></a>
                <a href="<?php echo e(route('schedule.index')); ?>" class="btn btn-bg-blue btn-sm mt-3">All Meetings</a>
            </div>
        </div>


        <!-- Table with stripped rows -->
        <div class="table-responsive">
            <table class="table datatable">
                <thead>
                    <tr>
                        <th>Circle Name</th>
                        <th>Franchise Name</th>
                        <th>City Name</th>
                        <th>Circle Type</th>
                        <th>Meeting Day</th>
                        
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $circle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $circleData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($circleData->circleName); ?></td>
                        <td><?php echo e($circleData->franchise->franchiseName ?? '-'); ?></td>
                        <td><?php echo e($circleData->city->cityName ?? '-'); ?></td>
                        <td><?php echo e($circleData->circletype->circleTypeName ?? '-'); ?></td>
                        <td>
                            
                            <?php if($circleData->meetingDay == 0): ?>
                            Sunday
                            <?php elseif($circleData->meetingDay == 1): ?>
                            Monday
                            <?php elseif($circleData->meetingDay == 2): ?>
                            Tuesday
                            <?php elseif($circleData->meetingDay == 3): ?>
                            Wednesday
                            <?php elseif($circleData->meetingDay == 4): ?>
                            Thursday
                            <?php elseif($circleData->meetingDay == 5): ?>
                            Friday
                            <?php elseif($circleData->meetingDay == 6): ?>
                            Saturday
                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </td>
                        
                        <td><?php echo e($circleData->status); ?></td>
                        <td>

                            <a href="<?php echo e(route('meetings.by.circle', $circleData->id)); ?>"
                                class="btn btn-bg-orange btn-sm">
                                <i class="bi bi-eye"></i>
                            </a>

                            <a href="<?php echo e(route('circle.edit', $circleData->id)); ?>" class="btn btn-bg-blue btn-sm ">
                                <i class="bi bi-pen"></i>
                            </a>

                            <a href="<?php echo e(route('circle.memberList', $circleData->id)); ?>" class="btn btn-info btn-sm ">
                                <i class="bi bi-person-lines-fill"></i>
                            </a>

                            <a href="<?php echo e(route('circle.delete', $circleData->id)); ?>" class="btn btn-danger btn-sm ">
                                <i class="bi bi-trash"></i>
                            </a>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- End Table with stripped rows -->
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/circle/index.blade.php ENDPATH**/ ?>