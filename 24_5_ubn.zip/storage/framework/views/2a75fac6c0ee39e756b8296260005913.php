<?php $__env->startSection('title', 'UBN - Testimonial'); ?>

<?php $__env->startSection('content'); ?>

<!-- Loader -->
<div id="loader" class="loader"></div>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
    </button>
    <strong>Success!</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
    </button>
    <strong>Error!</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <h4 class="mb-0 mt-3 text-blue">My Testimonials</h4>
            <a href="<?php echo e(route('testimonial.create')); ?>" class="btn btn-bg-orange btn-sm mt-3"><i
                    class="bi bi-plus-circle"></i></a>
        </div>
        <hr class="mb-5">
        <!-- Table with stripped rows -->
        <table class="table datatable mb-5">
            <thead>
                <tr>
                    <th>Circle Member</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $myTestimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myTestimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($myTestimonial->receiver->firstName ?? ''); ?> <?php echo e($myTestimonial->receiver->lastName ?? ''); ?></td>
                    <td><?php echo e($myTestimonial->message ?? ''); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($myTestimonial->date)->format('j M Y')); ?></td>
                    <td>
                        <a href="<?php echo e(route('testimonial.edit', $myTestimonial->id)); ?>" class="btn btn-primary btn-sm">
                            <i class="bi bi-pen"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <h4 class="mb-0 mt-3 text-blue">Received Testimonials</h4>
        </div>
        <hr class="mb-5">
        <!-- Table with stripped rows -->
        <table class="table datatable mb-5">
            <thead>
                <tr>
                    <th>Circle Member</th>
                    <th>Message</th>
                    <th>Uploaded Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($testimonial->sender->firstName ?? ''); ?> <?php echo e($testimonial->sender->lastName ?? ''); ?></td>
                    <td><?php echo e($testimonial->message ?? ''); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($testimonial->uploadedDate)->format('d-m-Y') ?? ''); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .loader {
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 9999;
        background: url('/path/to/your/loader.gif') 50% 50% no-repeat rgb(249,249,249);
        opacity: .8;
    }
    body.loading .loader {
        display: block;
    }
    body:not(.loading) .loader {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.body.classList.add('loading');
        window.addEventListener('load', function () {
            document.body.classList.remove('loading');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/testimonial/index.blade.php ENDPATH**/ ?>