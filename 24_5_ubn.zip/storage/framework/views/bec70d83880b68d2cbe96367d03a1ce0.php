<?php $__env->startSection('header', 'Testimonial'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>


<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">Testmonial</h4>
            <a href="<?php echo e(route('testimonial.archives')); ?>" class="btn btn-bg-orange mt-3 btn-sm"><i class="bi bi-archive"></i></a>
        </div>

        <!-- Table with stripped rows -->
        <table class="table datatable">
            <thead>
                <tr>
                    <th>Testimonial Giver</th>
                    <th>Testimonial Taker</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonialData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($testimonialData->user->firstName ?? '-'); ?>

                        <?php echo e($testimonialData->user->lastName ?? '-'); ?>

                    </td>
                    <td><?php echo e($testimonialData->member->firstName ?? '-'); ?>

                        <?php echo e($testimonialData->member->lastName ?? '-'); ?></td>
                    <td><?php echo e($testimonialData->message ?? '-'); ?></td>
                    
                    <td> <?php echo e(\Carbon\Carbon::parse($testimonialData->date)->format('j M Y')); ?> </td>
                    <td><?php echo e($testimonialData->status ?? '-'); ?></td>
                    <td>

                        <a href="<?php echo e(route('testimonial.destroy', $testimonialData->id)); ?>"
                            onclick="return confirm('Do You Want To Delete It ?')"
                            class="btn btn-danger btn-sm justify-content-center align-items-center"><i
                                class="bi bi-trash"></i></a>
                    </td>
                    

                        


                        
                        
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/testimonial/index.blade.php ENDPATH**/ ?>