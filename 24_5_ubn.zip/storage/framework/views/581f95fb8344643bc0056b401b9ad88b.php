<?php $__env->startSection('title', 'UBN - Circle Business'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>


<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mt-3 mb-5">
            <h4 class="text-blue">Circle Member Business</h4>
            <a href="<?php echo e(route('busGiver.index')); ?>" class="btn btn-bg-blue btn-sm">BACK</a>
        </div>
        <hr class="mb-5">
        <!-- Floating Labels Form -->
        <form class="m-3 needs-validation" id="circleMemberBusForm" enctype="multipart/form-data" method="post"
            action="<?php echo e(route('busGiver.update', $busGiver->id )); ?>" novalidate>
            <?php echo csrf_field(); ?>

            
                
                
            <div class="">

                <div class="form-floating mt-6">
                    <input type="hidden" name="businessGiverId" id="businessGiverId"
                        value="<?php echo e($busGiver->businessGiverId); ?>">
                    <input type="text" class="form-control <?php $__errorArgs = ['businessGiver'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="businessGiver" name="businessGiver"
                        value="<?php echo e($busGiver->businessGiver->firstName . ' ' . $busGiver->businessGiver->lastName); ?>"
                        placeholder="Reference Giver" readonly required>
                    <label for="businessGiver">Business Giver</label>
                    <?php $__errorArgs = ['businessGiver'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <input type="hidden" name="loginMemberId" value="<?php echo e($busGiver->loginMemberId); ?>">
            
            <div class="">
                <div class="form-floating mt-3">
                    <input type="text" class="form-control <?php $__errorArgs = ['contactNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="amount"
                        name="amount" placeholder="Amount" required>
                    <label for="amount">Amount</label>
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="">
                <div class="form-floating mt-3">
                    <input type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date" name="date"
                        placeholder="date" required value="<?php echo e(old('date', $busGiver->date)); ?>">
                    <label for="date">Date</label>
                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-tooltip">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="text-center mt-5">
                <button type="submit" class="btn btn-bg-blue">Submit</button>
                <button type="reset" class="btn btn-bg-orange">Reset</button>
            </div>
        </form><!-- End floating Labels Form -->
    </div>
</div>



<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <h4 class="mb-0 mt-3 text-blue">Payment History</h4>
            
        </div>
        <hr class="mb-5">
        <!-- Table with stripped rows -->
        <table class="table datatable mb-5">
            <thead>
                <tr>
                    
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Status</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php if($paymentHistory->isNotEmpty()): ?>
                <?php $__currentLoopData = $paymentHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentHistoryData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($paymentHistoryData->amount ?? '-'); ?></td>
                    <td><?php echo e($paymentHistoryData->date ?? '-'); ?></td>
                    <td><?php echo e($paymentHistoryData->status ?? '-'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                    <td colspan="5">No payment history data available</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/circlebusiness/edit.blade.php ENDPATH**/ ?>