<?php $__env->startSection('header', 'Conections'); ?>
<?php $__env->startSection('content'); ?>

    
    

    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="mb-0 mt-3">Connection Requests</h4>

            </div>

            <!-- Table with stripped rows -->
            <table class="table datatable">
                <thead>
                    <tr>
                        <th>Requested By</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $connections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($connection->user->firstName ?? '-'); ?> <?php echo e($connection->user->lastName ?? '-'); ?></td>
                            <td>
                                <?php if($connection->status == 'Pending'): ?>
                                    <span class="badge bg-info"><?php echo e($connection->status); ?></span>
                                <?php elseif($connection->status == 'Accepted'): ?>
                                    <span class="badge bg-success"><?php echo e($connection->status); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><?php echo e($connection->status); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($connection->status == 'Pending'): ?>
                                    <a class="btn btn-sm btn-success"
                                        href="<?php echo e(route('connection.accept', $connection->id)); ?>">Accept</a>
                                    <a class="btn btn-sm btn-danger"
                                        href="<?php echo e(route('connection.reject', $connection->id)); ?>">Reject</a>
                                <?php endif; ?>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- End Table with stripped rows -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/connections.blade.php ENDPATH**/ ?>