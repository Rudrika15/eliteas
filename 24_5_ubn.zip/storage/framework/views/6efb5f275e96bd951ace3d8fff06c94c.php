

<?php $__env->startSection('header', 'City'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Success !</strong> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert">
        
    </button>
    <strong>Error !</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0 mt-3">Circle Meeting</h4>
            <a href="<?php echo e(route('circlemeeting.create')); ?>" class="btn btn-primary btn-sm mt-3">ADD</a>
        </div>

        <!-- Table with stripped rows -->
        <table class="table datatable">
            <thead>
                <tr>
                    <th>Date & Time</th>
                    <th>Hotel Name</th>
                    <th>Total Meeting</th>
                    <th>Total Reference Given</th>
                    <th>Total Reference Taken</th>
                    <th>Total Business Given</th>
                    <th>Total Business Taken</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $circlemeeting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $circlemeetingData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($circlemeetingData->dateTime ?? '-'); ?></td>
                    <td><?php echo e($circlemeetingData->hotelName ?? '-'); ?></td>
                    <td><?php echo e($circlemeetingData->totalMeeting ?? '-'); ?></td>
                    <td><?php echo e($circlemeetingData->refGiven ?? '-'); ?></td>
                    <td><?php echo e($circlemeetingData->refTaken ?? '-'); ?></td>
                    <td><?php echo e($circlemeetingData->busTaken ?? '-'); ?></td>
                    <td><?php echo e($circlemeetingData->busTaken ?? '-'); ?></td>
                    <td><?php echo e($circlemeetingData->status ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('circlemeeting.edit', $circlemeetingData->id)); ?>"
                            class="btn btn-primary btn-sm">
                            <i class="bi bi-pen"></i>
                        </a>

                        

                        <a href="<?php echo e(route('circlemeeting.delete', $circlemeetingData->id)); ?>"
                            class="btn btn-danger btn-sm mt-1">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- End Table with stripped rows -->
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\biz\biz\resources\views/admin/circlemeeting/index.blade.php ENDPATH**/ ?>