<li class="nav-item">
    
    <ul id="users-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        
        
        
        

    </ul>
</li><!-- End Components Nav -->








<!-- End Components Nav -->



<li class="nav-item">
    <a class="nav-link " href="<?php echo e(route('franchise.index')); ?>">
        <i class="bi bi-person-vcard" style="color: #e76a35"></i>
        <span style="color: #1d2856">Franchise</span>
    </a>
</li>

<li class="nav-item">
    <a class="nav-link collapsed" href="<?php echo e(route('testimonials.indexAdmin')); ?>">
        <i class="bi bi-person" style="color: #e76a35"></i>
        <span style="color: #1d2856">Testimonial</span>
    </a>
</li>

<li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#training-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-person-gear" style="color: #e76a35"></i><span>Training</span><i
            class="bi bi-chevron-down ms-auto" style="color: #e76a35"></i>
    </a>
    <ul id="training-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('trainer.index')); ?>">
                <i class="bi bi-person-gear" style="color: #e76a35"></i>
                <span>Trainer Master</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('training.index')); ?>">
                <i class="bi bi-gear-wide-connected" style="color: #e76a35"></i>
                <span>Training</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('trainer.list')); ?>">
                <i class="bi bi-gear-wide-connected" style="color: #e76a35"></i>
                <span>Trainer List</span>
            </a>
        </li>

    </ul>
</li><!-- End Tables Nav -->

<li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#circle-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-plus-circle-dotted" style="color: #e76a35"></i><span>Circle</span><i
            class="bi bi-chevron-down ms-auto" style="color: #e76a35"></i>
    </a>
    <ul id="circle-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        



        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('circle.index')); ?>">
                <i class="bi bi-plus-circle-dotted" style="color: #e76a35"></i>
                <span>Circle List</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('circlemember.index')); ?>">
                <i class="bi bi-plus-circle-dotted" style="color: #e76a35"></i>
                <span>Circle Member</span>
            </a>
        </li>

        
        

        
        
    </ul>

<li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#master-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-gear" style="color: #e76a35"></i><span>Master</span><i class="bi bi-chevron-down ms-auto"
            style="color: #e76a35"></i>
    </a>

    <ul id="master-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('users.index')); ?>">
                <i class="bi bi-person" style="color: #e76a35"></i>
                <span>Admin User</span>
            </a>
        </li>
    </ul>

    <ul id="master-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('roles.index')); ?>">
                <i class="bi bi-shield" style="color: #e76a35"></i>
                <span>Roles</span>
            </a>
        </li>
    </ul>

    <ul id="master-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('circletype.index')); ?>">
                <i class="bi bi-plus-circle" style="color: #e76a35"></i>
                <span>Circle Type</span>
            </a>
        </li>
    </ul>


    <ul id="master-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('membershipType.index')); ?>">
                <i class="bi bi-globe" style="color: #e76a35"></i>
                <span>Membership Type</span>
            </a>
        </li>
    </ul>
    <ul id="master-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('tCategory.index')); ?>">
                <i class="bi bi-globe" style="color: #e76a35"></i>
                <span>Training Category</span>
            </a>
        </li>
    </ul>
    <ul id="master-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('bCategory.index')); ?>">
                <i class="bi bi-plus-circle" style="color: #e76a35"></i>
                <span>Business Category</span>
            </a>
        </li>
    </ul>
    <ul id="master-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('country.index')); ?>">
                <i class="bi bi-globe" style="color: #e76a35"></i>
                <span>Country</span>
            </a>
        </li>
    </ul>
    <ul id="master-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('state.index')); ?>">
                <i class="bi bi-flag" style="color: #e76a35"></i>
                <span>State</span>
            </a>
        </li>
    </ul>
    <ul id="master-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('city.index')); ?>">
                <i class="bi bi-buildings" style="color: #e76a35"></i>
                <span>City</span>
            </a>
        </li>
    </ul>


</li>

<li class="nav-item">
    <a class="nav-link " href="<?php echo e(route('allPayments.index')); ?>">
        <i class="bi bi-currency-rupee" style="color: #e76a35"></i>
        <span style="color: #1d2856">Payment History</span>
    </a>
</li>

<li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('subscription.memberSubscription.admin')); ?>">
            <i class="bi bi-substack" style="color: #e76a35"></i>
            <span class="text-blue">Member Subscriptions</span>
        </a>
    </li>





<!-- End Forms Nav --><?php /**PATH E:\Shiv\biz\biz\resources\views/layouts/adminmenu.blade.php ENDPATH**/ ?>