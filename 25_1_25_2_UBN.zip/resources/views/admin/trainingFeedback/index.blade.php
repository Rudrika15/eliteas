@extends('layouts.master')

@section('header', 'Training Master')
@section('content')

    <div class="container">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="card-title">Training List</h4>
                    <a href="{{ route('trainingMaster.create') }}" class="btn btn-bg-orange btn-sm mt-2 btn-tooltip"><i class="bi bi-plus-circle"></i>
                        <span class="btn-text">Add New Event Type</span>
                    </a>
                </div>

                <!-- Table with stripped rows -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Title</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($trainingMaster as $trainingMasterData)
                                <tr>
                                    <th>{{ ($trainingMaster->currentPage() - 1) * $trainingMaster->perPage() + $loop->index + 1 }}
                                    <td>{{ $trainingMasterData->trainingName }}</td>
                                    <td>{{ $trainingMasterData->status }}</td>
                                    <td>
                                        <a href="{{ route('trainingFeedback.adminIndex', $trainingMasterData->id) }}" class="btn btn-bg-orange btn-sm btn-tooltip">
                                            <i class="bi bi-eye"></i>
                                            <span class="btn-text">View Feedback</span>
                                        </a>

                                        <a href="{{ route('trainingMaster.edit', $trainingMasterData->id) }}" class="btn btn-bg-blue btn-sm btn-tooltip">
                                            <i class="bi bi-pen"></i>
                                            <span class="btn-text">Edit</span>
                                        </a>

                                        <a href="{{ route('trainingMaster.delete', $trainingMasterData->id) }}" class="btn btn-danger btn-sm btn-tooltip">
                                            <i class="bi bi-trash"></i>
                                            <span class="btn-text">Delete</span>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-end custom-pagination">
                        {!! $trainingMaster->links() !!}
                    </div>
                    <!-- End Table with stripped rows -->
                </div>
            </div>
        </div>
    </div>
@endsection
