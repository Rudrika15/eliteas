<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Razorpay;
use App\Models\Training;
use App\Models\TrainingRegister;
use App\Utils\Utils;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class TrainingController extends Controller
{
    // public function index(Request $request)
    // {
    //     try {
    //         $trainings = Training::with('trainer')
    //             ->where('status', 'Active')
    //             // ->where('start_date', '>=', Carbon::now()->subDays(1))
    //             ->where('date', '>', now()->toDateString())
    //             ->get();

    //         return Utils::sendResponse(['trainings' => $trainings], 'Trainings retrieved successfully', 200);
    //     } catch (\Throwable $th) {
    //         return Utils::errorResponse($th->getMessage(), 'Internal Server Error', 500);
    //     }
    // }

    // public function index(Request $request)
    // {
    //     try {
    //         $userId = Auth::id(); // Get authenticated user ID

    //         $trainings = Training::with('trainer')
    //             ->where('status', 'Active')
    //             ->whereDate('date', '>=', now()->toDateString())
    //             ->get()
    //             ->map(function ($training) use ($userId) {
    //                 $isRegistered = TrainingRegister::where('trainingId', $training->id)
    //                     ->where('userId', $userId) // Adjust column if needed
    //                     ->exists();

    //                 $training->setAttribute('is_registered', $isRegistered); // Proper way to attach custom property
    //                 return $training;
    //             });

    //         return Utils::sendResponse(['trainings' => $trainings], 'Trainings retrieved successfully', 200);
    //     } catch (\Throwable $th) {
    //         return Utils::errorResponse($th->getMessage(), 'Internal Server Error', 500);
    //     }
    // }

    public function index(Request $request)
    {
        try {
            $id = $request->input('id');
            $userId = Auth::id(); // Get the authenticated user ID

            if ($id) {
                $training = Training::with(['trainer', 'registerTraining'])
                    ->where('status', 'Active')
                    ->where('id', $id)
                    ->first();

                if (! $training) {
                    return Utils::errorResponse('Training not found', 'Not Found', 404);
                }

                // Add is_registered flag for this single training
                $isRegistered = TrainingRegister::where('trainingId', $training->id)
                    ->where('userId', $userId) // Adjust if your column name differs
                    ->exists();
                $training->setAttribute('is_registered', $isRegistered);

                return Utils::sendResponse(['training' => $training], 'Training retrieved successfully', 200);
            }

            $trainings = Training::with(['trainer', 'registerTraining'])
                ->where('status', 'Active')
                ->where('date', '>', now()->toDateString())
                ->get()
                ->map(function ($training) use ($userId) {
                    $isRegistered = TrainingRegister::where('trainingId', $training->id)
                        ->where('userId', $userId) // Adjust if needed
                        ->exists();
                    $training->setAttribute('is_registered', $isRegistered);

                    return $training;
                });

            return Utils::sendResponse(['trainings' => $trainings], 'Trainings retrieved successfully', 200);
        } catch (\Throwable $th) {
            return Utils::errorResponse($th->getMessage(), 'Internal Server Error', 500);
        }
    }

    public function show(Request $request, $id)
    {
        try {
            $training = Training::with('trainer')->findOrFail($id);

            return Utils::sendResponse(['training' => $training], 'Training retrieved successfully', 200);
        } catch (\Throwable $th) {
            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'trainerId' => 'required',
            'topic' => 'required',
        ]);

        if ($validator->fails()) {
            return Utils::errorResponse(['error' => $validator->errors()->first()], 'Invalid Input', 400);
        }

        try {
            $training = new Training;
            $training->trainerId = $request->trainerId;
            $training->topic = $request->topic;
            $training->status = 'Active';
            $training->save();

            return Utils::sendResponse(['training' => $training], 'Training Created Successfully', 201);
        } catch (\Throwable $th) {
            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'trainerId' => 'required',
            'topic' => 'required',
        ]);

        if ($validator->fails()) {
            return Utils::errorResponse(['error' => $validator->errors()->first()], 'Invalid Input', 400);
        }

        try {
            $training = Training::find($id);

            if (! $training) {
                return Utils::errorResponse(['error' => 'Training not found.'], 'Not Found', 404);
            }

            $training->trainerId = $request->trainerId;
            $training->topic = $request->topic;
            $training->status = 'Active';
            $training->save();

            return Utils::sendResponse(['training' => $training], 'Training Updated Successfully', 200);
        } catch (\Throwable $th) {
            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }

    public function delete(Request $request, $id)
    {
        try {
            $training = Training::find($id);

            if (! $training) {
                return Utils::errorResponse(['error' => 'Training not found.'], 'Not Found', 404);
            }

            $training->status = 'Deleted';
            $training->save();

            return Utils::sendResponse([], 'Training Deleted Successfully', 200);
        } catch (\Throwable $th) {
            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }

    // public function trainingRegister(Request $request, $trainingId, $trainerId)
    // {
    //     try {
    //         $register = new TrainingRegister();
    //         $register->userId = Auth::user()->id;
    //         $register->trainingId = $trainingId;
    //         $register->trainerId = $trainerId;
    //         $register->save();

    //         return Utils::sendResponse([], 'Training Registered Successfully', 200);
    //     } catch (\Throwable $th) {
    //         return Utils::errorResponse($th->getMessage(), 'Error Registering Training', 500);
    //     }
    // }

    public function trainingRegister(Request $request)
    {
        try {
            $trainingId = $request->trainingId;
            $trainerId = $request->trainerId;

            $register = new TrainingRegister;
            $register->userId = Auth::user()->id;
            $register->trainingId = $trainingId;
            // $register->trainerId = $trainerId;
            $register->save();

            $payment = new Razorpay;
            $payment->r_payment_id = $request->paymentId;
            $payment->user_email = Auth::user()->email;
            $payment->amount = $request->amount;
            $payment->save();

            return Utils::sendResponse([], 'Training Registered Successfully', 200);
        } catch (\Throwable $th) {
            throw $th;

            return Utils::errorResponse(['error' => $th->getMessage()], 'Internal Server Error', 500);
        }
    }
}
