<?php

namespace App\Http\Controllers;

use App\Exports\UsersExport;
use App\Models\Member;
use App\Models\User;
use DB;
use Hash;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Hash as FacadesHash;
use Illuminate\View\View;
use Maatwebsite\Excel\Facades\Excel;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request): View
    {
        $data = User::whereHas('roles', function ($q) {
            $q->whereIn('name', ['Admin', 'LT', 'Support']);
        })->latest()->paginate(10);

        return view('users.index', compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function userList(Request $request): View
    {
        $data = User::where('status', 'Active')->orderBy('firstName', 'ASC')->paginate(10);

        return view('users.userList', compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(): View
    {
        // $userId = User::first()->id;
        $roles = Role::pluck('name', 'name')->all();

        return view('users.create', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request): RedirectResponse
    {
        $this->validate($request, [
            'firstName' => 'required',
            'lastName' => 'required',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|same:confirm-password',
            'roles' => 'required',
        ]);

        $input = $request->except('_token');
        $input['password'] = FacadesHash::make($input['password']);

        // $user = User::create($input);
        $user = new User;
        $user->firstName = $request->input('firstName'); // Corrected accessing input
        $user->lastName = $request->input('lastName'); // Corrected accessing input
        $user->email = $request->input('email'); // Corrected accessing input
        $user->password = $input['password'];
        $user->save();
        $user->assignRole($request->input('roles'));

        // Check if the selected role is 'member'
        if ($request->input('roles') === 'Member') {
            $member = new Member;
            $member->userId = $user->id; // Assuming user_id column in members table
            $member->firstName = $request->input('firstName'); // Corrected accessing input
            $member->lastName = $request->input('lastName'); // Corrected accessing input
            $member->status = 'Active';
            $member->save();
        }

        return redirect()->route('users.index')
            ->with('success', 'User created successfully');
    }

    // bas tu aatlu yaad rakhje.... je tara thi chhe bija koi thi nai...

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id): View
    {
        $user = User::find($id);

        return view('users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id): View
    {
        $user = User::find($id);
        $roles = Role::pluck('name', 'name')->all();
        $userRole = $user->roles->pluck('name', 'name')->all();

        return view('users.edit', compact('user', 'roles', 'userRole'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id): RedirectResponse
    {
        $this->validate($request, [
            // 'name' => 'required',
            'email' => 'required|email|unique:users,email,'.$id,
            // 'password' => 'same:confirm-password',
            'roles' => 'required',
        ]);

        $input = $request->all();
        if (! empty($input['password'])) {
            $input['password'] = Hash::make($input['password']);
        } else {
            $input = Arr::except($input, ['password']);
        }

        $user = User::find($id);
        $user->update($input);
        DB::table('model_has_roles')->where('model_id', $id)->delete();

        $user->assignRole($request->input('roles'));

        return redirect()->route('users.index')
            ->with('success', 'User updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id): RedirectResponse
    {
        User::find($id)->delete();

        return redirect()->route('users.index')
            ->with('success', 'User deleted successfully');
    }

    public function getUserRoles($userId)
    {
        // Fetch user roles based on $userId
        $user = User::find($userId);

        if (! $user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        // Assuming user roles are stored in a roles column or relation
        $roles = $user->roles()->pluck('name')->toArray();

        return response()->json($roles);
    }

    public function export()
    {
        return Excel::download(new UsersExport, 'users.xlsx');
    }
}
