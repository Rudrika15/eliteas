<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Event extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'slug', 'event_date', 'start_time', 'end_time', 'amount'];

    public function circle()
    {
        return $this->belongsTo(Circle::class, 'circleId', 'id');
    }

    public function registrations()
    {
        return $this->hasMany(EventRegister::class, 'eventId'); // Make sure the foreign key is correct
    }

    public static function boot()
    {
        parent::boot();
        static::creating(function ($event) {
            $event->event_slug = Str::slug($event->title);
        });
    }
}
