<?php

namespace App\Providers;

use App\Models\Circle;
use App\Models\Member;
use App\Models\Connection;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\ServiceProvider;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $pendingCount = 0;

        if (Auth::check()) {
            $pendingCount = Connection::where('memberId', Auth::id())
                ->where('recordStatus', 'Active')
                ->where('status', 'Pending')
                ->count();
        }
        view()->share([
            'membersCount' => Member::where('status', 'Active')->count(),
            'circleCount' => Circle::where('status', 'Active')->count(),
            'pendingCount' => $pendingCount
        ]);

        Paginator::useBootstrap();
    }
}
