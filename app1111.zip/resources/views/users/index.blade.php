@extends('layouts.master')

{{-- naham karta shreeeharihi karta -  --}}

@section('content')
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="mt-3 card-title">Users Management</h2>
                <a class="btn btn-bg-orange mt-3 btn-sm btn-tooltip" href="{{ route('users.create') }}">
                    <i class="bi bi-person-plus"></i>
                    <span class="btn-text">Add User</span>
                </a>
            </div>

            <!-- Table with stripped rows -->
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Roles</th>
                            <th width="280px">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data as $key => $user)
                            <tr>
                                <td>{{ ++$i }}</td>
                                <td>{{ $user->firstName }}</td>
                                <td>{{ $user->lastName }}</td>
                                <td>{{ $user->email }}</td>
                                <td>
                                    @if (!empty($user->getRoleNames()))
                                        @foreach ($user->getRoleNames() as $v)
                                            <label class="badge bg-success">{{ $v }}</label>
                                        @endforeach
                                    @endif
                                </td>
                                <td>
                                    <a class="btn btn-bg-orange btn-sm btn-tooltip" href="{{ route('users.show', $user->id) }}">
                                        <i class="bi bi-eye"></i>
                                        <span class="btn-text">View User Details</span>
                                    </a>
                                    <a class="btn btn-bg-blue btn-sm btn-tooltip" href="{{ route('users.edit', $user->id) }}">
                                        <i class="bi bi-pencil"></i>
                                        <span class="btn-text">Edit User</span>
                                    </a>
                                    <button type="button" class="btn btn-danger btn-sm btn-tooltip" onclick="confirmDelete({{ $user->id }})">
                                        <i class="bi bi-trash"></i>
                                        <span class="btn-text">Delete User</span>
                                    </button>

                                    <form id="delete-form-{{ $user->id }}" action="{{ route('users.destroy', $user->id) }}" method="POST" style="display: none;">
                                        @csrf
                                        @method('DELETE')
                                    </form>

                                    <script>
                                        function confirmDelete(userId) {
                                            Swal.fire({
                                                title: 'Are you sure?',
                                                text: "You won't be able to revert this!",
                                                icon: 'warning',
                                                showCancelButton: true,
                                                confirmButtonColor: '#3085d6',
                                                cancelButtonColor: '#d33',
                                                confirmButtonText: 'Yes, delete it!'
                                            }).then((result) => {
                                                if (result.isConfirmed) {
                                                    console.log("Delete user with ID:", userId);
                                                    document.getElementById(`delete-form-${userId}`).submit();
                                                }
                                            });
                                        }
                                    </script>

                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <!-- End Table with stripped rows -->
            </div>
        </div>
    </div>
@endsection
